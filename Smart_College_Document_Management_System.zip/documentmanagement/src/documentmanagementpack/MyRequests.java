package documentmanagementpack;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class MyRequests extends JFrame {

    private String userId;
    private JTable requestTable;
    private DefaultTableModel model;

    public MyRequests(String userId) {

        this.userId = userId;

        setTitle("DocuFlow - My Requests");
        setSize(950, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        JLabel heading = new JLabel(
            "My Document Requests",
            SwingConstants.CENTER
        );

        heading.setFont(new Font("Arial", Font.BOLD, 26));
        heading.setBorder(
            BorderFactory.createEmptyBorder(20, 10, 10, 10)
        );

        add(heading, BorderLayout.NORTH);

        String[] columns = {
            "Request ID",
            "Document Name",
            "Request Date",
            "Reason",
            "Status"
        };

        model = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        requestTable = new JTable(model);
        requestTable.setFont(new Font("Arial", Font.PLAIN, 14));
        requestTable.setRowHeight(30);

        requestTable.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        JScrollPane scrollPane = new JScrollPane(requestTable);

        scrollPane.setBorder(
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        );

        add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 15));

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.PLAIN, 15));

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 20, 15)
        );

        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);

        add(buttonPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> loadRequests());

        closeButton.addActionListener(e -> dispose());

        loadRequests();
    }

    private void loadRequests() {

        model.setRowCount(0);

        String sql =
            "SELECT r.request_id, d.document_name, " +
            "r.request_date, r.reason, r.status " +
            "FROM DOCUMENT_REQUEST r " +
            "JOIN DOCUMENT_TYPE d " +
            "ON r.document_type_id = d.document_type_id " +
            "JOIN STUDENT s " +
            "ON r.student_id = s.student_id " +
            "WHERE s.user_id = ? " +
            "ORDER BY r.request_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, userId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Object[] row = {
                        rs.getInt("request_id"),
                        rs.getString("document_name"),
                        rs.getDate("request_date"),
                        rs.getString("reason"),
                        rs.getString("status")
                    };

                    model.addRow(row);
                }
            }

            if (model.getRowCount() == 0) {

                JOptionPane.showMessageDialog(
                    this,
                    "You have not submitted any document requests yet."
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Error loading requests: " + ex.getMessage()
            );
        }
    }
}
