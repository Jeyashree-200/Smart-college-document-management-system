
package documentmanagementpack;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AdminDashboard extends JFrame {

    private String userId;

    private Color navy = new Color(24, 39, 75);
    private Color background = new Color(245, 247, 251);
    private Color white = Color.WHITE;
    private Color blue = new Color(52, 120, 246);
    private Color green = new Color(39, 174, 96);
    private Color orange = new Color(230, 145, 40);
    private Color red = new Color(220, 70, 70);

    private JLabel totalRequests;
    private JLabel pendingRequests;
    private JLabel readyRequests;
    private JLabel totalDocuments;

    private JTable requestTable;
    private DefaultTableModel requestModel;

    // THREE DASHBOARD TABLES

    private JTable newlyApprovedTable;
    private DefaultTableModel newlyApprovedModel;

    private JTable processingTable;
    private DefaultTableModel processingModel;

    private JTable readyTable;
    private DefaultTableModel readyModel;

    private JTable documentTable;
    private DefaultTableModel documentModel;

    private JTable accountTable;
    private DefaultTableModel accountModel;

    private JPanel contentPanel;
    private CardLayout cardLayout;

    public AdminDashboard(String userId) {

        this.userId = userId;

        setTitle("DocuFlow - Admin Dashboard");
        setSize(1250, 780);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        createSidebar();
        createContent();

        loadDashboardData();
        loadRequests();

        setVisible(true);
    }

    // SIDEBAR

    private void createSidebar() {

        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(230, 0));
        sidebar.setBackground(navy);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("  DocuFlow");
        logo.setFont(new Font("Arial", Font.BOLD, 27));
        logo.setForeground(white);
        logo.setBorder(BorderFactory.createEmptyBorder(30, 15, 35, 10));

        sidebar.add(logo);

        addMenuButton(sidebar, "Dashboard");
        addMenuButton(sidebar, "All Requests");
        addMenuButton(sidebar, "Document Types");
        addMenuButton(sidebar, "Manage Accounts");

        sidebar.add(Box.createVerticalGlue());

        JButton logout = createMenuButton("Logout");

        logout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        sidebar.add(logout);
        sidebar.add(Box.createVerticalStrut(25));

        add(sidebar, BorderLayout.WEST);
    }

    private void addMenuButton(JPanel panel, String name) {

        JButton button = createMenuButton(name);

        button.addActionListener(e -> {

            if (name.equals("Dashboard")) {

                cardLayout.show(contentPanel, "Dashboard");
                loadDashboardData();
                loadRequests();

            } else if (name.equals("All Requests")) {

                cardLayout.show(contentPanel, "Requests");
                loadRequests();

            } else if (name.equals("Document Types")) {

                cardLayout.show(contentPanel, "Documents");
                loadDocumentTypes();

            } else if (name.equals("Manage Accounts")) {

                cardLayout.show(contentPanel, "Accounts");
                loadAccounts();
            }
        });

        panel.add(button);
    }

    private JButton createMenuButton(String name) {

        JButton button = new JButton(name);

        button.setFont(new Font("Arial", Font.BOLD, 15));
        button.setForeground(white);
        button.setBackground(navy);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(230, 50));
        button.setPreferredSize(new Dimension(230, 50));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 10));

        return button;
    }

    // BUTTON STYLING

    private void styleButton(JButton button, Color color) {

        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setForeground(white);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(155, 38));
    }

    // CONTENT

    private void createContent() {

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        contentPanel.add(createDashboardPanel(), "Dashboard");
        contentPanel.add(createRequestPanel(), "Requests");
        contentPanel.add(createDocumentPanel(), "Documents");
        contentPanel.add(createAccountPanel(), "Accounts");

        add(contentPanel, BorderLayout.CENTER);
    }

    // HEADER WITH COLLEGE IMAGE

    private JPanel createHeader(String title, String subtitle) {

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel(title);
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(navy);

        JLabel sub = new JLabel(subtitle);
        sub.setFont(new Font("Arial", Font.PLAIN, 14));
        sub.setForeground(Color.GRAY);

        textPanel.add(heading);
        textPanel.add(Box.createVerticalStrut(7));
        textPanel.add(sub);

        header.add(textPanel, BorderLayout.WEST);

        try {

            java.net.URL imageURL =
                getClass().getResource("/images/mepco.jpg");

            if (imageURL != null) {

                ImageIcon icon = new ImageIcon(imageURL);

                Image image = icon.getImage().getScaledInstance(
                    100, 80, Image.SCALE_SMOOTH
                );

                JLabel imageLabel = new JLabel(new ImageIcon(image));
                header.add(imageLabel, BorderLayout.EAST);
            }

        } catch (Exception ex) {
            System.out.println("College image not found.");
        }

        return header;
    }

    // DASHBOARD

    private JPanel createDashboardPanel() {

        JPanel main = new JPanel(new BorderLayout(20, 20));
        main.setBackground(background);
        main.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        main.add(
            createHeader(
                "Admin Dashboard",
                "Manage document requests and collection"
            ),
            BorderLayout.NORTH
        );

        JPanel center = new JPanel(new BorderLayout(15, 15));
        center.setOpaque(false);

        // DASHBOARD CARDS

        JPanel cards = new JPanel(new GridLayout(1, 4, 15, 15));
        cards.setOpaque(false);

        totalRequests = new JLabel("0");
        pendingRequests = new JLabel("0");
        readyRequests = new JLabel("0");
        totalDocuments = new JLabel("0");

        cards.add(createCard("Total Requests", totalRequests, blue));
        cards.add(createCard("Pending Requests", pendingRequests, orange));
        cards.add(createCard("Ready for Collection", readyRequests, green));
        cards.add(createCard("Document Types", totalDocuments, navy));

        center.add(cards, BorderLayout.NORTH);

        // THREE SEPARATE TABLES

        JPanel tablesPanel = new JPanel();
        tablesPanel.setLayout(new BoxLayout(tablesPanel, BoxLayout.Y_AXIS));
        tablesPanel.setBackground(background);

        // 1. NEWLY APPROVED

        newlyApprovedModel = createRequestModel();
        newlyApprovedTable = new JTable(newlyApprovedModel);

        styleTable(newlyApprovedTable);

        JPanel approvedPanel = createDashboardSection(
            "Newly Approved Requests",
            newlyApprovedTable,
            "Move to Processing",
            blue,
            () -> updateSelectedRequest(newlyApprovedTable)
        );

        // 2. PROCESSING

        processingModel = createRequestModel();
        processingTable = new JTable(processingModel);

        styleTable(processingTable);

        JPanel processingPanel = createDashboardSection(
            "Processing Requests",
            processingTable,
            "Update Selected Request",
            green,
            () -> updateSelectedRequest(processingTable)
        );

        // 3. READY FOR COLLECTION

        readyModel = createRequestModel();
        readyTable = new JTable(readyModel);

        styleTable(readyTable);

        JPanel readyPanel = createDashboardSection(
            "Ready for Collection",
            readyTable,
            null,
            null,
            null
        );

        tablesPanel.add(approvedPanel);
        tablesPanel.add(Box.createVerticalStrut(15));

        tablesPanel.add(processingPanel);
        tablesPanel.add(Box.createVerticalStrut(15));

        tablesPanel.add(readyPanel);

        JScrollPane dashboardScroll = new JScrollPane(tablesPanel);
        dashboardScroll.setBorder(null);
        dashboardScroll.getVerticalScrollBar().setUnitIncrement(16);

        center.add(dashboardScroll, BorderLayout.CENTER);

        // REFRESH BUTTON

        JButton refresh = new JButton("Refresh Dashboard");
        styleButton(refresh, navy);

        refresh.addActionListener(e -> {
            loadDashboardData();
            loadRequests();
        });

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        bottom.add(refresh);

        center.add(bottom, BorderLayout.SOUTH);

        main.add(center, BorderLayout.CENTER);

        return main;
    }

    // DASHBOARD SECTION

    private JPanel createDashboardSection(
            String title,
            JTable table,
            String buttonText,
            Color buttonColor,
            Runnable action) {

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(white);

        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 225, 235)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel heading = new JLabel(title);
        heading.setFont(new Font("Arial", Font.BOLD, 18));
        heading.setForeground(navy);

        panel.add(heading, BorderLayout.NORTH);

        table.setPreferredScrollableViewportSize(
            new Dimension(800, 110)
        );

        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        if (buttonText != null) {

            JButton button = new JButton(buttonText);
            styleButton(button, buttonColor);

            button.addActionListener(e -> action.run());

            JPanel buttonPanel = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
            );

            buttonPanel.setOpaque(false);
            buttonPanel.add(button);

            panel.add(buttonPanel, BorderLayout.SOUTH);
        }

        panel.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 230)
        );

        return panel;
    }

    // REQUEST PANEL

    private JPanel createRequestPanel() {

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(background);
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        panel.add(
            createHeader(
                "All Requests",
                "View and manage approved document requests"
            ),
            BorderLayout.NORTH
        );

        requestModel = createRequestModel();
        requestTable = new JTable(requestModel);

        styleTable(requestTable);

        panel.add(new JScrollPane(requestTable), BorderLayout.CENTER);

        JButton update = new JButton("Update Selected Request");
        styleButton(update, blue);

        update.addActionListener(e ->
            updateSelectedRequest(requestTable)
        );

        JButton refresh = new JButton("Refresh");
        styleButton(refresh, green);

        refresh.addActionListener(e -> loadRequests());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.setOpaque(false);

        buttons.add(update);
        buttons.add(refresh);

        panel.add(buttons, BorderLayout.SOUTH);

        return panel;
    }

    private DefaultTableModel createRequestModel() {

        String[] columns = {
            "Request ID", "Student ID", "Document Name",
            "Request Date", "Reason", "Status", "Fee"
        };

        return new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    // DOCUMENT TYPES

    private JPanel createDocumentPanel() {

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(background);
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        panel.add(
            createHeader(
                "Manage Document Types",
                "Add, edit and delete available document types"
            ),
            BorderLayout.NORTH
        );

        documentModel = new DefaultTableModel(
            new String[]{
                "ID", "Document Name", "HOD Approval",
                "Description", "Fee"
            }, 0
        ) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        documentTable = new JTable(documentModel);
        styleTable(documentTable);

        panel.add(new JScrollPane(documentTable), BorderLayout.CENTER);

        JButton add = new JButton("Add Document");
        styleButton(add, green);
        add.addActionListener(e -> addDocumentType());

        JButton edit = new JButton("Edit Selected");
        styleButton(edit, blue);
        edit.addActionListener(e -> editDocumentType());

        JButton delete = new JButton("Delete Selected");
        styleButton(delete, red);
        delete.addActionListener(e -> deleteDocumentType());

        JButton refresh = new JButton("Refresh");
        styleButton(refresh, navy);
        refresh.addActionListener(e -> loadDocumentTypes());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.setOpaque(false);

        buttons.add(add);
        buttons.add(edit);
        buttons.add(delete);
        buttons.add(refresh);

        panel.add(buttons, BorderLayout.SOUTH);

        return panel;
    }

    // MANAGE ACCOUNTS

    private JPanel createAccountPanel() {

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(background);
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        panel.add(
            createHeader(
                "Manage Accounts",
                "Create and manage Staff Advisor and HOD accounts"
            ),
            BorderLayout.NORTH
        );

        accountModel = new DefaultTableModel(
            new String[]{
                "User ID", "Name", "Email",
                "Role", "Department", "Section", "Status"
            }, 0
        ) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        accountTable = new JTable(accountModel);
        styleTable(accountTable);

        panel.add(new JScrollPane(accountTable), BorderLayout.CENTER);

        JButton addAdvisor = new JButton("Add Staff Advisor");
        styleButton(addAdvisor, blue);
        addAdvisor.addActionListener(e ->
            addAccount("STAFF_ADVISOR")
        );

        JButton addHOD = new JButton("Add HOD");
        styleButton(addHOD, green);
        addHOD.addActionListener(e ->
            addAccount("HOD")
        );

        JButton activate = new JButton("Activate");
        styleButton(activate, green);
        activate.addActionListener(e ->
            updateAccountStatus(1)
        );

        JButton deactivate = new JButton("Deactivate");
        styleButton(deactivate, red);
        deactivate.addActionListener(e ->
            updateAccountStatus(0)
        );

        JButton refresh = new JButton("Refresh");
        styleButton(refresh, navy);
        refresh.addActionListener(e -> loadAccounts());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.setOpaque(false);

        buttons.add(addAdvisor);
        buttons.add(addHOD);
        buttons.add(activate);
        buttons.add(deactivate);
        buttons.add(refresh);

        panel.add(buttons, BorderLayout.SOUTH);

        return panel;
    }

    // LOAD ACCOUNTS

    private void loadAccounts() {

        accountModel.setRowCount(0);

        String sql =
            "SELECT u.USER_ID, u.NAME, u.EMAIL, u.ROLE, " +
            "s.DEPARTMENT, s.SECTION, u.IS_ACTIVE " +
            "FROM USERS u JOIN STAFF_ADVISOR s " +
            "ON u.USER_ID = s.USER_ID " +

            "UNION ALL " +

            "SELECT u.USER_ID, u.NAME, u.EMAIL, u.ROLE, " +
            "h.DEPARTMENT, NULL AS SECTION, u.IS_ACTIVE " +
            "FROM USERS u JOIN HOD h " +
            "ON u.USER_ID = h.USER_ID " +

            "ORDER BY 1";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                String role = rs.getString("ROLE");
                String active = rs.getString("IS_ACTIVE");

                if ("STAFF_ADVISOR".equalsIgnoreCase(role)) {
                    role = "Staff Advisor";
                }

                if ("Y".equalsIgnoreCase(active) || "1".equals(active)) {
                    active = "Active";
                } else {
                    active = "Inactive";
                }

                accountModel.addRow(new Object[]{
                    rs.getString("USER_ID"),
                    rs.getString("NAME"),
                    rs.getString("EMAIL"),
                    role,
                    rs.getString("DEPARTMENT"),
                    rs.getString("SECTION"),
                    active
                });
            }

        } catch (SQLException ex) {
            showError("Account loading error", ex);
        }
    }

    // ADD STAFF ADVISOR / HOD

    private void addAccount(String role) {

        JTextField nameField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JTextField departmentField = new JTextField(20);
        JTextField sectionField = new JTextField(20);

        Font labelFont = new Font("Arial", Font.BOLD, 14);
        Font fieldFont = new Font("Arial", Font.PLAIN, 14);

        JPanel form = new JPanel(new GridLayout(0, 2, 15, 15));

        form.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel departmentLabel = new JLabel("Department:");
        JLabel sectionLabel = new JLabel("Section:");

        nameLabel.setFont(labelFont);
        emailLabel.setFont(labelFont);
        passwordLabel.setFont(labelFont);
        departmentLabel.setFont(labelFont);
        sectionLabel.setFont(labelFont);

        nameField.setFont(fieldFont);
        emailField.setFont(fieldFont);
        passwordField.setFont(fieldFont);
        departmentField.setFont(fieldFont);
        sectionField.setFont(fieldFont);

        form.add(nameLabel);
        form.add(nameField);

        form.add(emailLabel);
        form.add(emailField);

        form.add(passwordLabel);
        form.add(passwordField);

        form.add(departmentLabel);
        form.add(departmentField);

        if (role.equals("STAFF_ADVISOR")) {
            form.add(sectionLabel);
            form.add(sectionField);
        }

        String title = role.equals("HOD")
            ? "Add HOD Account"
            : "Add Staff Advisor Account";

        int result = JOptionPane.showConfirmDialog(
            this,
            form,
            title,
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String department = departmentField.getText().trim();
        String section = sectionField.getText().trim();

        if (name.isEmpty() || email.isEmpty()
                || password.isEmpty() || department.isEmpty()
                || (role.equals("STAFF_ADVISOR") && section.isEmpty())) {

            JOptionPane.showMessageDialog(
                this, "Please fill all the fields."
            );
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            JOptionPane.showMessageDialog(
                this, "Enter a valid email address."
            );
            return;
        }

        Connection con = null;

        try {

            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            String checkSql =
                "SELECT COUNT(*) FROM USERS WHERE EMAIL=?";

            try (PreparedStatement ps = con.prepareStatement(checkSql)) {

                ps.setString(1, email);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next() && rs.getInt(1) > 0) {
                        JOptionPane.showMessageDialog(
                            this, "This email is already registered."
                        );
                        con.rollback();
                        return;
                    }
                }
            }

            String userSql =
                "INSERT INTO USERS " +
                "(NAME, EMAIL, PASSWORD, ROLE, IS_ACTIVE) " +
                "VALUES (?, ?, ?, ?, 1)";

            try (PreparedStatement ps = con.prepareStatement(userSql)) {

                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, password);
                ps.setString(4, role);

                ps.executeUpdate();
            }

            int generatedUserId = 0;

            String idSql =
                "SELECT USER_ID FROM USERS WHERE EMAIL=?";

            try (PreparedStatement ps = con.prepareStatement(idSql)) {

                ps.setString(1, email);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        generatedUserId = rs.getInt("USER_ID");
                    } else {
                        throw new SQLException("User ID not generated.");
                    }
                }
            }

            String roleSql;

            if (role.equals("STAFF_ADVISOR")) {

                roleSql =
                    "INSERT INTO STAFF_ADVISOR " +
                    "(USER_ID, DEPARTMENT, SECTION) VALUES (?, ?, ?)";

            } else {

                roleSql =
                    "INSERT INTO HOD " +
                    "(USER_ID, DEPARTMENT) VALUES (?, ?)";
            }

            try (PreparedStatement ps = con.prepareStatement(roleSql)) {

                ps.setInt(1, generatedUserId);
                ps.setString(2, department);

                if (role.equals("STAFF_ADVISOR")) {
                    ps.setString(3, section);
                }

                ps.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(
                this,
                title + " created successfully!\nUser ID: "
                + generatedUserId
            );

            loadAccounts();

        } catch (SQLException ex) {

            rollback(con);
            showError("Account creation error", ex);

        } finally {

            closeConnection(con);
        }
    }

    // ACTIVATE / DEACTIVATE

    private void updateAccountStatus(int status) {

        int row = accountTable.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                this, "Please select an account."
            );
            return;
        }

        int selectedUserId = Integer.parseInt(
            accountModel.getValueAt(row, 0).toString()
        );

        String accountName =
            accountModel.getValueAt(row, 1).toString();

        String action = status == 1 ? "activate" : "deactivate";

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to " + action +
            " the account of " + accountName + "?",
            "Confirm Account Status",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
            "UPDATE USERS SET IS_ACTIVE=? WHERE USER_ID=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, status);
            ps.setInt(2, selectedUserId);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                this, "Account status updated successfully."
            );

            loadAccounts();

        } catch (SQLException ex) {
            showError("Account status update error", ex);
        }
    }

    // DASHBOARD CARDS

    private JPanel createCard(String title, JLabel value, Color color) {

        JPanel card = new JPanel();

        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(white);

        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 233, 240)),
            BorderFactory.createEmptyBorder(20, 18, 20, 18)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(Color.GRAY);

        value.setFont(new Font("Arial", Font.BOLD, 30));
        value.setForeground(color);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(15));
        card.add(value);

        return card;
    }

    // TABLE STYLING

    private void styleTable(JTable table) {

        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setRowHeight(34);

        table.setSelectionBackground(new Color(220, 230, 250));
        table.setSelectionForeground(Color.BLACK);

        table.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        table.getTableHeader().setBackground(
            new Color(220, 230, 245)
        );

        table.getTableHeader().setForeground(navy);
    }

    // DASHBOARD DATA

    private void loadDashboardData() {

        try (Connection con = DBConnection.getConnection()) {

            String sql =
                "SELECT COUNT(*) total, " +
                "SUM(CASE WHEN LOWER(status) LIKE '%pending%' " +
                "THEN 1 ELSE 0 END) pending, " +
                "SUM(CASE WHEN LOWER(status) LIKE '%ready%' " +
                "THEN 1 ELSE 0 END) ready " +
                "FROM DOCUMENT_REQUEST";

            try (PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    totalRequests.setText(
                        String.valueOf(rs.getInt("total"))
                    );

                    pendingRequests.setText(
                        String.valueOf(rs.getInt("pending"))
                    );

                    readyRequests.setText(
                        String.valueOf(rs.getInt("ready"))
                    );
                }
            }

            try (PreparedStatement ps =
                    con.prepareStatement(
                        "SELECT COUNT(*) FROM DOCUMENT_TYPE"
                    );
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    totalDocuments.setText(
                        String.valueOf(rs.getInt(1))
                    );
                }
            }

        } catch (SQLException ex) {
            showError("Dashboard loading error", ex);
        }
    }

    // LOAD REQUESTS INTO SEPARATE TABLES

    private void loadRequests() {

        if (requestModel == null) {
            return;
        }

        requestModel.setRowCount(0);

        newlyApprovedModel.setRowCount(0);
        processingModel.setRowCount(0);
        readyModel.setRowCount(0);

        String sql =
            "SELECT r.REQUEST_ID, r.STUDENT_ID, d.DOCUMENT_NAME, " +
            "r.REQUEST_DATE, r.REASON, r.STATUS, " +
            "NVL(d.DOCUMENT_FEE,0) DOCUMENT_FEE " +
            "FROM DOCUMENT_REQUEST r " +
            "JOIN DOCUMENT_TYPE d ON " +
            "r.DOCUMENT_TYPE_ID = d.DOCUMENT_TYPE_ID " +

            "WHERE UPPER(NVL(r.STATUS,' ')) NOT LIKE '%REJECT%' " +

            "AND EXISTS ( " +
            "SELECT 1 FROM APPROVAL a " +
            "WHERE a.REQUEST_ID = r.REQUEST_ID " +
            "AND UPPER(REPLACE(a.APPROVER_ROLE,' ','_')) = 'STAFF_ADVISOR' " +
            "AND UPPER(a.APPROVAL_STATUS) = 'APPROVED') " +

            "AND (UPPER(TRIM(d.HOD_APPROVAL_REQUIRED)) = 'NO' " +
            "OR EXISTS ( " +
            "SELECT 1 FROM APPROVAL h " +
            "WHERE h.REQUEST_ID = r.REQUEST_ID " +
            "AND UPPER(TRIM(h.APPROVER_ROLE)) = 'HOD' " +
            "AND UPPER(h.APPROVAL_STATUS) = 'APPROVED')) " +

            "ORDER BY r.REQUEST_DATE DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Object[] row = {
                    rs.getInt("REQUEST_ID"),
                    rs.getString("STUDENT_ID"),
                    rs.getString("DOCUMENT_NAME"),
                    rs.getDate("REQUEST_DATE"),
                    rs.getString("REASON"),
                    rs.getString("STATUS"),
                    rs.getBigDecimal("DOCUMENT_FEE")
                };

                // ALL ELIGIBLE REQUESTS

                requestModel.addRow(row);

                String status = rs.getString("STATUS");

                if (status == null) {
                    continue;
                }

                status = status.trim().toUpperCase();

                // NEWLY APPROVED

                if (status.startsWith("APPROVED")) {

                    newlyApprovedModel.addRow(row);
                }

                // PROCESSING

                else if (status.equals("PROCESSING")) {

                    processingModel.addRow(row);
                }

                // READY FOR COLLECTION

                else if (status.equals("READY FOR COLLECTION")) {

                    readyModel.addRow(row);
                }
            }

        } catch (SQLException ex) {
            showError("Request loading error", ex);
        }
    }

    // UPDATE SELECTED REQUEST

    private void updateSelectedRequest(JTable selectedTable) {

        int row = selectedTable.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                this, "Please select a request."
            );
            return;
        }

        int requestId = Integer.parseInt(
            selectedTable.getValueAt(row, 0).toString()
        );

        String currentStatus =
            selectedTable.getValueAt(row, 5).toString();

        String[] options = {
            "Processing", "Ready for Collection"
        };

        String selectedStatus = (String) JOptionPane.showInputDialog(
            this,
            "Select the new request status:",
            "Update Request Status",
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            currentStatus.equalsIgnoreCase("Processing")
                ? "Ready for Collection" : "Processing"
        );

        if (selectedStatus == null) {
            return;
        }

        if (selectedStatus.equals("Processing")
                && currentStatus.equalsIgnoreCase("Ready for Collection")) {

            JOptionPane.showMessageDialog(
                this,
                "A request that is ready for collection " +
                "cannot be moved back to Processing."
            );

            return;
        }

        processRequest(requestId, selectedStatus);
    }

    // PROCESS REQUEST

    private void processRequest(int requestId, String newStatus) {

        Connection con = null;

        try {

            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            int adminId = 0;

            String adminSql =
                "SELECT ADMIN_ID FROM ADMIN WHERE USER_ID=?";

            try (PreparedStatement ps = con.prepareStatement(adminSql)) {

                ps.setInt(1, Integer.parseInt(userId));

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        adminId = rs.getInt("ADMIN_ID");
                    } else {
                        throw new SQLException("Admin record not found.");
                    }
                }
            }

            String detailsSql =
                "SELECT r.STUDENT_ID, d.DOCUMENT_NAME, " +
                "NVL(d.DOCUMENT_FEE,0) FEE " +
                "FROM DOCUMENT_REQUEST r " +
                "JOIN DOCUMENT_TYPE d ON " +
                "r.DOCUMENT_TYPE_ID=d.DOCUMENT_TYPE_ID " +
                "WHERE r.REQUEST_ID=?";

            String studentId;
            String documentName;
            double fee;

            try (PreparedStatement ps =
                    con.prepareStatement(detailsSql)) {

                ps.setInt(1, requestId);

                try (ResultSet rs = ps.executeQuery()) {

                    if (!rs.next()) {
                        throw new SQLException("Request not found.");
                    }

                    studentId = rs.getString("STUDENT_ID");
                    documentName = rs.getString("DOCUMENT_NAME");
                    fee = rs.getDouble("FEE");
                }
            }

            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE DOCUMENT_REQUEST SET STATUS=? " +
                    "WHERE REQUEST_ID=?")) {

                ps.setString(1, newStatus);
                ps.setInt(2, requestId);
                ps.executeUpdate();
            }

            int processCount = 0;

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM ADMIN_PROCESS " +
                    "WHERE REQUEST_ID=?")) {

                ps.setInt(1, requestId);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        processCount = rs.getInt(1);
                    }
                }
            }

            if (processCount == 0) {

                String insert =
                    "INSERT INTO ADMIN_PROCESS " +
                    "(REQUEST_ID, ADMIN_ID, PROCESS_STATUS, " +
                    "PROCESS_DATE, READY_DATE, AMOUNT) " +
                    "VALUES (?, ?, ?, SYSDATE, " +
                    "CASE WHEN ?='Ready for Collection' " +
                    "THEN SYSDATE ELSE NULL END, ?)";

                try (PreparedStatement ps =
                        con.prepareStatement(insert)) {

                    ps.setInt(1, requestId);
                    ps.setInt(2, adminId);
                    ps.setString(3, newStatus);
                    ps.setString(4, newStatus);
                    ps.setDouble(5, fee);

                    ps.executeUpdate();
                }

            } else {

                String update =
                    "UPDATE ADMIN_PROCESS SET PROCESS_STATUS=?, " +
                    "PROCESS_DATE=SYSDATE, " +
                    "READY_DATE=CASE WHEN ?='Ready for Collection' " +
                    "THEN SYSDATE ELSE READY_DATE END, " +
                    "AMOUNT=? WHERE REQUEST_ID=?";

                try (PreparedStatement ps =
                        con.prepareStatement(update)) {

                    ps.setString(1, newStatus);
                    ps.setString(2, newStatus);
                    ps.setDouble(3, fee);
                    ps.setInt(4, requestId);

                    ps.executeUpdate();
                }
            }

            if (newStatus.equals("Ready for Collection")) {

                String message =
                    "Your " + documentName +
                    " is ready for collection. Amount to be paid: Rs. " +
                    String.format("%.2f", fee) +
                    ". Please visit the Admin Block, pay the amount " +
                    "and collect your document.";

                String notificationSql =
                    "INSERT INTO NOTIFICATION " +
                    "(STUDENT_ID, REQUEST_ID, MESSAGE, " +
                    "NOTIFICATION_DATE, IS_READ) " +
                    "VALUES (?, ?, ?, SYSDATE, 'N')";

                try (PreparedStatement ps =
                        con.prepareStatement(notificationSql)) {

                    ps.setString(1, studentId);
                    ps.setInt(2, requestId);
                    ps.setString(3, message);

                    ps.executeUpdate();
                }
            }

            con.commit();

            JOptionPane.showMessageDialog(
                this, "Request status updated successfully."
            );

            loadDashboardData();
            loadRequests();

        } catch (NumberFormatException ex) {

            rollback(con);

            JOptionPane.showMessageDialog(
                this,
                "Admin ID must be numeric. " +
                "Please check the userId passed to AdminDashboard."
            );

        } catch (SQLException ex) {

            rollback(con);
            showError("Request update error", ex);

        } finally {

            closeConnection(con);
        }
    }

    // LOAD DOCUMENT TYPES

    private void loadDocumentTypes() {

        documentModel.setRowCount(0);

        String sql =
            "SELECT DOCUMENT_TYPE_ID, DOCUMENT_NAME, " +
            "HOD_APPROVAL_REQUIRED, DESCRIPTION, " +
            "NVL(DOCUMENT_FEE,0) DOCUMENT_FEE " +
            "FROM DOCUMENT_TYPE ORDER BY DOCUMENT_TYPE_ID";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                documentModel.addRow(new Object[]{
                    rs.getInt("DOCUMENT_TYPE_ID"),
                    rs.getString("DOCUMENT_NAME"),
                    rs.getString("HOD_APPROVAL_REQUIRED"),
                    rs.getString("DESCRIPTION"),
                    rs.getBigDecimal("DOCUMENT_FEE")
                });
            }

        } catch (SQLException ex) {
            showError("Document type loading error", ex);
        }
    }

    // ADD DOCUMENT TYPE

    private void addDocumentType() {

        JTextField nameField = new JTextField();
        JTextField descriptionField = new JTextField();
        JTextField feeField = new JTextField("0");

        JComboBox<String> hodBox =
            new JComboBox<>(new String[]{"Yes", "No"});

        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));

        form.add(new JLabel("Document Name:"));
        form.add(nameField);

        form.add(new JLabel("Description:"));
        form.add(descriptionField);

        form.add(new JLabel("HOD Approval Required:"));
        form.add(hodBox);

        form.add(new JLabel("Document Fee:"));
        form.add(feeField);

        int result = JOptionPane.showConfirmDialog(
            this,
            form,
            "Add Document Type",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String name = nameField.getText().trim();
        String description = descriptionField.getText().trim();

        if (name.isEmpty()) {

            JOptionPane.showMessageDialog(
                this, "Enter document name."
            );

            return;
        }

        try {

            double fee = Double.parseDouble(feeField.getText().trim());

            if (fee < 0) {
                JOptionPane.showMessageDialog(
                    this, "Fee cannot be negative."
                );
                return;
            }

            String sql =
                "INSERT INTO DOCUMENT_TYPE " +
                "(DOCUMENT_NAME, HOD_APPROVAL_REQUIRED, " +
                "DESCRIPTION, DOCUMENT_FEE) " +
                "VALUES (?, ?, ?, ?)";

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, name);
                ps.setString(2, hodBox.getSelectedItem().toString());
                ps.setString(3, description);
                ps.setDouble(4, fee);

                ps.executeUpdate();
            }

            JOptionPane.showMessageDialog(
                this, "Document type added successfully."
            );

            loadDocumentTypes();
            loadDashboardData();

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                this, "Enter a valid fee."
            );

        } catch (SQLException ex) {
            showError("Document type insert error", ex);
        }
    }

    // EDIT DOCUMENT TYPE

    private void editDocumentType() {

        int row = documentTable.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                this, "Select a document type to edit."
            );

            return;
        }

        int id = Integer.parseInt(
            documentModel.getValueAt(row, 0).toString()
        );

        JTextField nameField = new JTextField(
            documentModel.getValueAt(row, 1).toString()
        );

        JComboBox<String> hodBox =
            new JComboBox<>(new String[]{"Yes", "No"});

        hodBox.setSelectedItem(
            documentModel.getValueAt(row, 2).toString()
        );

        Object descriptionValue =
            documentModel.getValueAt(row, 3);

        JTextField descriptionField = new JTextField(
            descriptionValue == null
                ? "" : descriptionValue.toString()
        );

        Object feeValue = documentModel.getValueAt(row, 4);

        JTextField feeField = new JTextField(
            feeValue == null ? "0" : feeValue.toString()
        );

        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));

        form.add(new JLabel("Document Name:"));
        form.add(nameField);

        form.add(new JLabel("Description:"));
        form.add(descriptionField);

        form.add(new JLabel("HOD Approval Required:"));
        form.add(hodBox);

        form.add(new JLabel("Document Fee:"));
        form.add(feeField);

        int result = JOptionPane.showConfirmDialog(
            this,
            form,
            "Edit Document Type",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        if (nameField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                this, "Enter document name."
            );

            return;
        }

        try {

            double fee = Double.parseDouble(feeField.getText().trim());

            if (fee < 0) {
                JOptionPane.showMessageDialog(
                    this, "Fee cannot be negative."
                );
                return;
            }

            String sql =
                "UPDATE DOCUMENT_TYPE SET DOCUMENT_NAME=?, " +
                "HOD_APPROVAL_REQUIRED=?, DESCRIPTION=?, " +
                "DOCUMENT_FEE=? WHERE DOCUMENT_TYPE_ID=?";

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, nameField.getText().trim());
                ps.setString(2, hodBox.getSelectedItem().toString());
                ps.setString(3, descriptionField.getText().trim());
                ps.setDouble(4, fee);
                ps.setInt(5, id);

                ps.executeUpdate();
            }

            JOptionPane.showMessageDialog(
                this, "Document type updated successfully."
            );

            loadDocumentTypes();
            loadDashboardData();

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                this, "Enter a valid fee."
            );

        } catch (SQLException ex) {
            showError("Document type update error", ex);
        }
    }

    // DELETE DOCUMENT TYPE

    private void deleteDocumentType() {

        int row = documentTable.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                this, "Select a document type to delete."
            );

            return;
        }

        int id = Integer.parseInt(
            documentModel.getValueAt(row, 0).toString()
        );

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this document type?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection con = DBConnection.getConnection()) {

            String checkSql =
                "SELECT COUNT(*) FROM DOCUMENT_REQUEST " +
                "WHERE DOCUMENT_TYPE_ID=?";

            try (PreparedStatement ps = con.prepareStatement(checkSql)) {

                ps.setInt(1, id);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next() && rs.getInt(1) > 0) {

                        JOptionPane.showMessageDialog(
                            this,
                            "This document type is already used in requests. " +
                            "It cannot be deleted."
                        );

                        return;
                    }
                }
            }

            String deleteSql =
                "DELETE FROM DOCUMENT_TYPE WHERE DOCUMENT_TYPE_ID=?";

            try (PreparedStatement ps =
                    con.prepareStatement(deleteSql)) {

                ps.setInt(1, id);
                ps.executeUpdate();
            }

            JOptionPane.showMessageDialog(
                this, "Document type deleted successfully."
            );

            loadDocumentTypes();
            loadDashboardData();

        } catch (SQLException ex) {
            showError("Document type delete error", ex);
        }
    }

    // ERROR HANDLING

    private void showError(String message, SQLException ex) {

        JOptionPane.showMessageDialog(
            this,
            message + "\n" + ex.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    private void rollback(Connection con) {

        if (con != null) {

            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void closeConnection(Connection con) {

        if (con != null) {

            try {
                con.setAutoCommit(true);
                con.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
