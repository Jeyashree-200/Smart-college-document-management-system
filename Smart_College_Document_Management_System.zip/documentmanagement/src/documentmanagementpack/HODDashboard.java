
package documentmanagementpack;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class HODDashboard extends JFrame {

    private static final long serialVersionUID = 1L;

    String hodName;
    String userId;
    String hodId;
    String department;

    JLabel totalLabel;
    JLabel pendingLabel;

    JTable requestTable;
    DefaultTableModel model;

    Color darkBlue = new Color(25, 42, 86);
    Color lightBackground = new Color(245, 247, 252);
    Color blue = new Color(55, 100, 210);
    Color green = new Color(35, 160, 110);
    Color red = new Color(220, 75, 75);

    public HODDashboard(String hodName, String userId) {

        this.hodName = hodName;
        this.userId = userId;

        setTitle("DocuFlow - HOD Dashboard");
        setSize(1250, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        loadHODDetails();

        JPanel sidebar = new JPanel();
        sidebar.setBackground(darkBlue);
        sidebar.setPreferredSize(new Dimension(225, 720));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("  DOCUFLOW");
        logo.setFont(new Font("Arial", Font.BOLD, 25));
        logo.setForeground(Color.WHITE);
        logo.setBorder(BorderFactory.createEmptyBorder(30, 10, 35, 10));

        JLabel roleLabel = new JLabel("  HOD PANEL");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        roleLabel.setForeground(new Color(180, 195, 225));
        roleLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 20, 10));

        JButton dashboardButton = createSideButton("Dashboard");
        JButton pendingButton = createSideButton("Pending Requests");
        JButton profileButton = createSideButton("My Profile");
        JButton logoutButton = createSideButton("Logout");

        sidebar.add(logo);
        sidebar.add(roleLabel);
        sidebar.add(dashboardButton);
        sidebar.add(pendingButton);
        sidebar.add(profileButton);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(logoutButton);
        sidebar.add(Box.createVerticalStrut(25));

        add(sidebar, BorderLayout.WEST);

        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setBackground(lightBackground);
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        );

        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 8));
        headerPanel.setOpaque(false);

        JLabel heading = new JLabel("HOD Dashboard");
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(darkBlue);

        JLabel welcome = new JLabel(
            "Welcome, " + hodName + "   |   " + department
        );
        welcome.setFont(new Font("Arial", Font.PLAIN, 15));
        welcome.setForeground(Color.DARK_GRAY);

        headerPanel.add(heading);
        headerPanel.add(welcome);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel(new BorderLayout(15, 18));
        contentPanel.setOpaque(false);

        JPanel cardPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        cardPanel.setOpaque(false);

        totalLabel = new JLabel("0");
        pendingLabel = new JLabel("0");

        cardPanel.add(createCard(
            "TOTAL HOD REQUESTS", totalLabel, blue
        ));

        cardPanel.add(createCard(
            "PENDING APPROVALS", pendingLabel, green
        ));

        String[] columns = {
            "Request ID",
            "Student Name",
            "Document Type",
            "Status"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        requestTable = new JTable(model);
        requestTable.setRowHeight(42);
        requestTable.setFont(new Font("Arial", Font.PLAIN, 14));
        requestTable.setSelectionBackground(new Color(215, 228, 255));
        requestTable.setSelectionForeground(Color.BLACK);
        requestTable.setGridColor(new Color(230, 230, 230));
        requestTable.setShowVerticalLines(false);
        requestTable.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        JTableHeader tableHeader = requestTable.getTableHeader();
        tableHeader.setFont(new Font("Arial", Font.BOLD, 14));
        tableHeader.setBackground(darkBlue);
        tableHeader.setPreferredSize(new Dimension(100, 45));
        tableHeader.setReorderingAllowed(false);

        DefaultTableCellRenderer headerRenderer =
            new DefaultTableCellRenderer();

        headerRenderer.setBackground(darkBlue);
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setFont(new Font("Arial", Font.BOLD, 14));
        headerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        for (int i = 0; i < requestTable.getColumnCount(); i++) {
            requestTable.getColumnModel()
                .getColumn(i).setHeaderRenderer(headerRenderer);
        }

        requestTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        requestTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        requestTable.getColumnModel().getColumn(2).setPreferredWidth(250);
        requestTable.getColumnModel().getColumn(3).setPreferredWidth(180);

        JScrollPane scrollPane = new JScrollPane(requestTable);
        scrollPane.setBorder(
            BorderFactory.createLineBorder(new Color(225, 228, 235))
        );

        JPanel tablePanel = new JPanel(new BorderLayout(0, 15));
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(
            BorderFactory.createEmptyBorder(18, 18, 18, 18)
        );

        JLabel tableTitle = new JLabel("Requests Awaiting HOD Approval");
        tableTitle.setFont(new Font("Arial", Font.BOLD, 19));
        tableTitle.setForeground(darkBlue);

        JLabel instruction = new JLabel(
            "Double-click a request to view complete details"
        );
        instruction.setFont(new Font("Arial", Font.PLAIN, 12));
        instruction.setForeground(Color.GRAY);

        JPanel tableHeadingPanel = new JPanel(new BorderLayout());
        tableHeadingPanel.setBackground(Color.WHITE);
        tableHeadingPanel.add(tableTitle, BorderLayout.NORTH);
        tableHeadingPanel.add(instruction, BorderLayout.SOUTH);

        tablePanel.add(tableHeadingPanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh");
        styleButton(refreshButton, blue);

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT)
        );
        buttonPanel.setOpaque(false);
        buttonPanel.add(refreshButton);

        contentPanel.add(cardPanel, BorderLayout.NORTH);
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel, BorderLayout.CENTER);

        dashboardButton.addActionListener(e -> loadRequests());
        pendingButton.addActionListener(e -> loadRequests());
        profileButton.addActionListener(e -> showProfile());
        refreshButton.addActionListener(e -> loadRequests());

        requestTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    showRequestDetails();
                }
            }
        });

        logoutButton.addActionListener(e -> {

            int choice = JOptionPane.showConfirmDialog(
                this,
                "Do you want to logout?",
                "Logout",
                JOptionPane.YES_NO_OPTION
            );

            if (choice == JOptionPane.YES_OPTION) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });

        loadRequests();
    }

    private JButton createSideButton(String text) {

        JButton button = new JButton(text);

        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(darkBlue);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(225, 50));
        button.setBorder(
            BorderFactory.createEmptyBorder(10, 25, 10, 10)
        );
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return button;
    }

    private JPanel createCard(
        String title,
        JLabel value,
        Color color
    ) {

        JPanel card = new JPanel(new GridLayout(2, 1, 0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 5, 0, 0, color),
            BorderFactory.createEmptyBorder(15, 18, 15, 15)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 13));
        titleLabel.setForeground(new Color(75, 85, 105));

        value.setFont(new Font("Arial", Font.BOLD, 30));
        value.setForeground(color);

        card.add(titleLabel);
        card.add(value);

        return card;
    }

    private void styleButton(JButton button, Color color) {

        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(130, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadHODDetails() {

        String sql =
            "SELECT hod_id, department " +
            "FROM HOD WHERE user_id = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, Integer.parseInt(userId));

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    hodId = rs.getString("hod_id");
                    department = rs.getString("department");
                } else {
                    JOptionPane.showMessageDialog(
                        this,
                        "HOD details not found."
                    );
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Error loading HOD profile: " + ex.getMessage()
            );
        }
    }

    private void showProfile() {

        HODProfile profile = new HODProfile(
            hodName,
            hodId,
            department,
            userId
        );

        profile.setVisible(true);
    }

    private void loadRequests() {

        model.setRowCount(0);

        if (department == null) {
            return;
        }

        String sql =
            "SELECT dr.request_id, u.name AS student_name, " +
            "dt.document_name, dr.status " +
            "FROM DOCUMENT_REQUEST dr " +
            "JOIN STUDENT s ON dr.student_id = s.student_id " +
            "JOIN USERS u ON s.user_id = u.user_id " +
            "JOIN DOCUMENT_TYPE dt " +
            "ON dr.document_type_id = dt.document_type_id " +
            "WHERE s.department = ? " +
            "AND dr.status = 'Sent to HOD' " +
            "AND dt.hod_approval_required = 'Yes' " +
            "ORDER BY dr.request_date DESC";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, department);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    model.addRow(new Object[] {
                        rs.getInt("request_id"),
                        rs.getString("student_name"),
                        rs.getString("document_name"),
                        rs.getString("status")
                    });
                }
            }

            updateCounts();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Error loading requests:\n" + ex.getMessage()
            );
        }
    }

    private void showRequestDetails() {

        int row = requestTable.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(
                this,
                "Please select a request."
            );
            return;
        }

        int requestId = Integer.parseInt(
            model.getValueAt(row, 0).toString()
        );

        String sql =
            "SELECT dr.request_id, dr.student_id, " +
            "u.name AS student_name, s.department, " +
            "s.year_of_study, dt.document_name, " +
            "dr.reason, dr.request_date, dr.status, " +

            "(SELECT MAX(u2.name) KEEP " +
            "(DENSE_RANK LAST ORDER BY a.approval_date) " +
            "FROM APPROVAL a " +
            "JOIN USERS u2 ON a.approver_id = u2.user_id " +
            "WHERE a.request_id = dr.request_id " +
            "AND a.approver_role = 'STAFF_ADVISOR' " +
            "AND a.approval_status = 'Approved') AS advisor_name, " +

            "(SELECT MAX(a.approval_date) " +
            "FROM APPROVAL a " +
            "WHERE a.request_id = dr.request_id " +
            "AND a.approver_role = 'STAFF_ADVISOR' " +
            "AND a.approval_status = 'Approved') AS advisor_date " +

            "FROM DOCUMENT_REQUEST dr " +
            "JOIN STUDENT s ON dr.student_id = s.student_id " +
            "JOIN USERS u ON s.user_id = u.user_id " +
            "JOIN DOCUMENT_TYPE dt " +
            "ON dr.document_type_id = dt.document_type_id " +
            "WHERE dr.request_id = ? AND s.department = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, requestId);
            ps.setString(2, department);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    displayDetails(rs);
                } else {
                    JOptionPane.showMessageDialog(
                        this,
                        "Request details not found."
                    );
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Error loading request details: " + ex.getMessage()
            );
        }
    }

    private void displayDetails(ResultSet rs) throws SQLException {

        int requestId = rs.getInt("request_id");
        String status = rs.getString("status");

        JDialog dialog = new JDialog(
            this,
            "Request Details - " + requestId,
            true
        );

        dialog.setSize(650, 650);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(darkBlue);
        header.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel title = new JLabel("Complete Request Details");
        title.setFont(new Font("Arial", Font.BOLD, 23));
        title.setForeground(Color.WHITE);

        JLabel requestNumber = new JLabel("Request ID: " + requestId);
        requestNumber.setFont(new Font("Arial", Font.PLAIN, 14));
        requestNumber.setForeground(Color.WHITE);

        header.add(title, BorderLayout.NORTH);
        header.add(requestNumber, BorderLayout.SOUTH);

        JPanel detailsPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setBorder(
            BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        addDetail(detailsPanel, "Student ID", rs.getString("student_id"));
        addDetail(detailsPanel, "Student Name", rs.getString("student_name"));
        addDetail(detailsPanel, "Department", rs.getString("department"));
        addDetail(detailsPanel, "Year of Study", rs.getString("year_of_study"));
        addDetail(detailsPanel, "Document Type", rs.getString("document_name"));
        addDetail(detailsPanel, "Reason", rs.getString("reason"));
        addDetail(detailsPanel, "Request Date", String.valueOf(rs.getTimestamp("request_date")));
        addDetail(detailsPanel, "Staff Advisor", rs.getString("advisor_name"));
        addDetail(detailsPanel, "Advisor Approval Date", String.valueOf(rs.getTimestamp("advisor_date")));
        addDetail(detailsPanel, "Current Status", status);

        JScrollPane scrollPane = new JScrollPane(detailsPanel);
        scrollPane.setBorder(null);

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 12, 15)
        );
        buttonPanel.setBackground(lightBackground);

        JButton approveButton = new JButton("Approve");
        JButton rejectButton = new JButton("Reject");
        JButton closeButton = new JButton("Close");

        styleButton(approveButton, green);
        styleButton(rejectButton, red);
        styleButton(closeButton, darkBlue);

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        buttonPanel.add(closeButton);

        if (!"Sent to HOD".equals(status)) {
            approveButton.setEnabled(false);
            rejectButton.setEnabled(false);
        }

        approveButton.addActionListener(e -> {
            dialog.dispose();
            updateRequest(requestId, "Approved");
        });

        rejectButton.addActionListener(e -> {
            dialog.dispose();
            updateRequest(requestId, "Rejected");
        });

        closeButton.addActionListener(e -> dialog.dispose());

        dialog.add(header, BorderLayout.NORTH);
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private void addDetail(
        JPanel panel,
        String label,
        String value
    ) {

        JLabel nameLabel = new JLabel(label);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 13));
        nameLabel.setForeground(darkBlue);

        JLabel valueLabel = new JLabel(
            value == null ? "Not available" : value
        );
        valueLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        valueLabel.setForeground(Color.DARK_GRAY);

        panel.add(nameLabel);
        panel.add(valueLabel);
    }

    private void updateRequest(int requestId, String decision) {

        String remarks = "";

        if (decision.equals("Rejected")) {

            remarks = JOptionPane.showInputDialog(
                this,
                "Enter reason for rejection:"
            );

            if (remarks == null) {
                return;
            }

            remarks = remarks.trim();

            if (remarks.isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Rejection reason is required."
                );
                return;
            }
        }

        String newStatus;

        if (decision.equals("Approved")) {
            newStatus = "Approved by HOD";
        } else {
            newStatus = "Rejected by HOD";
        }

        String updateSql =
            "UPDATE DOCUMENT_REQUEST " +
            "SET status = ? " +
            "WHERE request_id = ? AND status = 'Sent to HOD'";

        String approvalSql =
            "INSERT INTO APPROVAL " +
            "(request_id, approver_id, approver_role, " +
            "approval_status, remarks) " +
            "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection()) {

            con.setAutoCommit(false);

            try {

                try (PreparedStatement updatePs =
                    con.prepareStatement(updateSql)) {

                    updatePs.setString(1, newStatus);
                    updatePs.setInt(2, requestId);

                    int updated = updatePs.executeUpdate();

                    if (updated == 0) {
                        con.rollback();

                        JOptionPane.showMessageDialog(
                            this,
                            "This request has already been reviewed."
                        );
                        return;
                    }
                }

                try (PreparedStatement approvalPs =
                    con.prepareStatement(approvalSql)) {

                    approvalPs.setInt(1, requestId);
                    approvalPs.setInt(2, Integer.parseInt(userId));
                    approvalPs.setString(3, "HOD");
                    approvalPs.setString(4, decision);

                    if (remarks.isEmpty()) {
                        approvalPs.setNull(5, Types.VARCHAR);
                    } else {
                        approvalPs.setString(5, remarks);
                    }

                    approvalPs.executeUpdate();
                }

                if (decision.equals("Rejected")) {

                	String studentNotification =
                	        "INSERT INTO NOTIFICATION " +
                	        "(student_id, request_id, message) " +
                	        "SELECT student_id, request_id, ? " +
                	        "FROM DOCUMENT_REQUEST " +
                	        "WHERE request_id = ?";

                	    try (PreparedStatement ps =
                	        con.prepareStatement(studentNotification)) {

                	        ps.setString(
                	            1,
                	            "Your document request has been Rejected by HOD. " +
                	            "Reason: " + remarks
                	        );

                	        ps.setInt(2, requestId);
                	        ps.executeUpdate();
                	    }

                	    // Notify correct Staff Advisor using department and section
                	    String advisorNotification =
                	        "INSERT INTO NOTIFICATION " +
                	        "(student_id, recipient_user_id, request_id, message) " +
                	        "SELECT dr.student_id, sa.user_id, dr.request_id, ? " +
                	        "FROM DOCUMENT_REQUEST dr " +
                	        "JOIN STUDENT s ON dr.student_id = s.student_id " +
                	        "JOIN STAFF_ADVISOR sa " +
                	        "ON UPPER(TRIM(s.department)) = UPPER(TRIM(sa.department)) " +
                	        "AND UPPER(TRIM(s.section)) = UPPER(TRIM(sa.section)) " +
                	        "WHERE dr.request_id = ?";

                	    try (PreparedStatement ps =
                	        con.prepareStatement(advisorNotification)) {

                	        ps.setString(
                	            1,
                	            "The request " + requestId +
                	            " was Rejected by HOD. Reason: " + remarks
                	        );

                	        ps.setInt(2, requestId);
                	        ps.executeUpdate();
                	    }                }

                con.commit();

                String message;

                if (decision.equals("Approved")) {
                    message = "Request approved and forwarded to Admin.";
                } else {
                    message =
                        "Request rejected. Student and Staff Advisor have been notified.";
                }

                JOptionPane.showMessageDialog(this, message);

                loadRequests();

            } catch (SQLException ex) {

                con.rollback();
                throw ex;
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Error updating request:\n" + ex.getMessage()
            );
        }
}

    private void updateCounts() {

        String sql =
            "SELECT " +
            "COUNT(*) AS total, " +
            "NVL(SUM(CASE WHEN status = 'Sent to HOD' " +
            "THEN 1 ELSE 0 END), 0) AS pending " +
            "FROM DOCUMENT_REQUEST dr " +
            "JOIN STUDENT s ON dr.student_id = s.student_id " +
            "JOIN DOCUMENT_TYPE dt " +
            "ON dr.document_type_id = dt.document_type_id " +
            "WHERE s.department = ? " +
            "AND dt.hod_approval_required = 'Yes' " +
            "AND dr.status IN ('Sent to HOD', " +
            "'Approved by HOD', 'Rejected by HOD')";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, department);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    totalLabel.setText(
                        String.valueOf(rs.getInt("total"))
                    );

                    pendingLabel.setText(
                        String.valueOf(rs.getInt("pending"))
                    );
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Error loading counts: " + ex.getMessage()
            );
        }
    }
}
