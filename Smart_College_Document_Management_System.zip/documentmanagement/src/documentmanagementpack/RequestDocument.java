
package documentmanagementpack;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;

public class RequestDocument extends JFrame implements ActionListener
{
    JLabel studentIdLabel, studentNameLabel;
    JLabel departmentLabel, yearLabel;

    JComboBox<String> documentBox;
    JTextArea reasonArea;

    JButton submitButton, cancelButton;

    int[] documentIds = new int[100];
    int documentCount = 0;

    String userId;

    Color bgColor = new Color(245, 248, 252);
    Color panelColor = new Color(235, 243, 250);
    Color blueColor = new Color(45, 110, 170);
    Color textColor = new Color(35, 75, 112);
    Color borderColor = new Color(180, 205, 225);

    public RequestDocument(String userId)
    {
        this.userId = userId;

        setTitle("DocuFlow - Request Document");
        setSize(750, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(bgColor);

        JPanel headingPanel = new JPanel(new BorderLayout(15, 0));
        headingPanel.setBackground(panelColor);
        headingPanel.setBorder(
            BorderFactory.createEmptyBorder(15, 25, 15, 25)
        );

        JPanel headingTextPanel = new JPanel(new GridLayout(2, 1, 0, 5));
        headingTextPanel.setBackground(panelColor);

        JLabel heading = new JLabel("Request Document");
        heading.setFont(new Font("Arial", Font.BOLD, 27));
        heading.setForeground(textColor);

        JLabel subtitle = new JLabel(
            "Fill in the details to request your document"
        );
        subtitle.setFont(new Font("Arial", Font.PLAIN, 15));
        subtitle.setForeground(new Color(90, 110, 130));

        headingTextPanel.add(heading);
        headingTextPanel.add(subtitle);

        JLabel imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);

        java.net.URL imageURL =
            getClass().getResource("/images/request_document.png.png");

        if (imageURL != null)
        {
            ImageIcon icon = new ImageIcon(imageURL);

            Image image = icon.getImage().getScaledInstance(
                150, 120, Image.SCALE_SMOOTH
            );

            imageLabel.setIcon(new ImageIcon(image));
        }

        headingPanel.add(headingTextPanel, BorderLayout.CENTER);
        headingPanel.add(imageLabel, BorderLayout.EAST);

        add(headingPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(
            BorderFactory.createCompoundBorder(
                new LineBorder(borderColor, 1),
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
            )
        );

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 8, 10, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        Font labelFont = new Font("Arial", Font.BOLD, 16);
        Font fieldFont = new Font("Arial", Font.PLAIN, 16);

        studentIdLabel = new JLabel();
        studentNameLabel = new JLabel();
        departmentLabel = new JLabel();
        yearLabel = new JLabel();

        documentBox = new JComboBox<String>();
        documentBox.setFont(fieldFont);
        documentBox.setBackground(Color.WHITE);

        reasonArea = new JTextArea(4, 20);
        reasonArea.setFont(fieldFont);
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        reasonArea.setBorder(
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        );

        JScrollPane reasonScroll = new JScrollPane(reasonArea);
        reasonScroll.setBorder(new LineBorder(borderColor, 1));

        addFormRow(formPanel, gbc, 0, "Student ID", studentIdLabel, labelFont);
        addFormRow(formPanel, gbc, 1, "Student Name", studentNameLabel, labelFont);
        addFormRow(formPanel, gbc, 2, "Department", departmentLabel, labelFont);
        addFormRow(formPanel, gbc, 3, "Year of Study", yearLabel, labelFont);
        addFormRow(formPanel, gbc, 4, "Document Type", documentBox, labelFont);
        addFormRow(formPanel, gbc, 5, "Reason for Request", reasonScroll, labelFont);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);

        submitButton = new JButton("Submit Request");
        cancelButton = new JButton("Cancel");

        submitButton.setFont(new Font("Arial", Font.BOLD, 15));
        submitButton.setBackground(blueColor);
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setOpaque(true);
        submitButton.setBorderPainted(false);

        cancelButton.setFont(new Font("Arial", Font.BOLD, 15));
        cancelButton.setBackground(Color.WHITE);
        cancelButton.setForeground(textColor);
        cancelButton.setFocusPainted(false);
        cancelButton.setBorder(new LineBorder(blueColor, 1));

        submitButton.addActionListener(this);
        cancelButton.addActionListener(this);

        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(bgColor);
        centerPanel.setBorder(
            BorderFactory.createEmptyBorder(0, 25, 20, 25)
        );
        centerPanel.add(formPanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        loadStudentDetails();
        loadDocumentTypes();

        setVisible(true);
    }

    private void addFormRow(
        JPanel panel,
        GridBagConstraints gbc,
        int row,
        String labelText,
        JComponent field,
        Font labelFont
    )
    {
        JLabel label = new JLabel(labelText);
        label.setFont(labelFont);
        label.setForeground(textColor);

        if (field instanceof JLabel)
        {
            field.setFont(new Font("Arial", Font.PLAIN, 16));
            field.setForeground(textColor);
        }
        else
        {
            field.setFont(new Font("Arial", Font.PLAIN, 16));
        }

        if (!(field instanceof JScrollPane))
        {
            field.setBorder(
                BorderFactory.createCompoundBorder(
                    new LineBorder(borderColor, 1),
                    BorderFactory.createEmptyBorder(8, 8, 8, 8)
                )
            );
        }

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.35;
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.65;
        panel.add(field, gbc);
    }

    private void loadStudentDetails()
    {
        try
        {
            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT s.student_id, u.name, s.department, s.year_of_study " +
                "FROM STUDENT s JOIN USERS u ON s.user_id = u.user_id " +
                "WHERE u.user_id = ?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, userId);

            ResultSet rs = ps.executeQuery();

            if (rs.next())
            {
                studentIdLabel.setText(rs.getString("student_id"));
                studentNameLabel.setText(rs.getString("name"));
                departmentLabel.setText(rs.getString("department"));
                yearLabel.setText(rs.getString("year_of_study"));
            }

            rs.close();
            ps.close();
            con.close();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(
                this, "Unable to load student details: " + e.getMessage()
            );
        }
    }

    private void loadDocumentTypes()
    {
        try
        {
            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT document_type_id, document_name " +
                "FROM DOCUMENT_TYPE ORDER BY document_type_id";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            documentBox.removeAllItems();
            documentCount = 0;

            while (rs.next())
            {
                documentIds[documentCount] =
                    rs.getInt("document_type_id");

                documentBox.addItem(rs.getString("document_name"));
                documentCount++;
            }

            rs.close();
            ps.close();
            con.close();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(
                this, "Unable to load document types: " + e.getMessage()
            );
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == submitButton)
        {
            submitRequest();
        }

        if (e.getSource() == cancelButton)
        {
            dispose();
        }
    }

    private void submitRequest()
    {
        if (studentIdLabel.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(
                this, "Student details not found!"
            );
            return;
        }

        int selectedIndex = documentBox.getSelectedIndex();

        if (selectedIndex == -1)
        {
            JOptionPane.showMessageDialog(
                this, "Please select a document type!"
            );
            return;
        }

        String reason = reasonArea.getText().trim();

        if (reason.isEmpty())
        {
            JOptionPane.showMessageDialog(
                this, "Please enter the reason for requesting the document!"
            );
            return;
        }

        try
        {
            Connection con = DBConnection.getConnection();

            String sql =
                "INSERT INTO DOCUMENT_REQUEST " +
                "(student_id, document_type_id, reason) " +
                "VALUES (?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, studentIdLabel.getText());
            ps.setInt(2, documentIds[selectedIndex]);
            ps.setString(3, reason);

            int result = ps.executeUpdate();

            if (result > 0)
            {
                JOptionPane.showMessageDialog(
                    this, "Document request submitted successfully!"
                );

                reasonArea.setText("");
                dispose();
            }

            ps.close();
            con.close();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(
                this, "Error submitting request: " + e.getMessage()
            );
        }
    }
}
