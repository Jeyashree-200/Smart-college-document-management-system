
package documentmanagementpack;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.*;

public class StudentDashboard extends JFrame {

    private String studentName;
    private String userId;

    private JLabel unreadBadge;
    private JPanel notificationCard;

    private javax.swing.Timer collectionNotificationTimer;
    private javax.swing.Timer bannerAnimationTimer;

    private JPanel notificationBanner;
    private JLabel bannerMessageLabel;
    private int bannerHeight = 0;
    private int currentNotificationId = -1;
    private boolean bannerVisible = false;

    private Color background = new Color(245, 247, 251);
    private Color sidebarColor = new Color(24, 43, 69);
    private Color primaryColor = new Color(45, 105, 180);
    private Color textColor = new Color(40, 55, 75);
    private Color mutedColor = new Color(120, 132, 148);
    private Color borderColor = new Color(225, 231, 239);

    public StudentDashboard(String studentName, String userId) {

        this.studentName = studentName;
        this.userId = userId;

        setTitle("DocuFlow - Student Dashboard");
        setSize(1200, 760);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(createSidebar(), BorderLayout.WEST);
        add(createMainContent(), BorderLayout.CENTER);

        refreshUnreadCount();

        setVisible(true);

        startCollectionNotificationChecker();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                if (collectionNotificationTimer != null) {
                    collectionNotificationTimer.stop();
                }
                if (bannerAnimationTimer != null) {
                    bannerAnimationTimer.stop();
                }
            }
        });
    }

    private JPanel createSidebar() {

        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(260, 0));
        sidebar.setBackground(sidebarColor);
        sidebar.setLayout(new BorderLayout());

        JPanel top = new JPanel();
        top.setBackground(sidebarColor);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBorder(new EmptyBorder(30, 22, 20, 15));

        JLabel logo = new JLabel("DocuFlow");
        logo.setFont(new Font("Arial", Font.BOLD, 24));
        logo.setPreferredSize(new Dimension(210, 35));
        logo.setMaximumSize(new Dimension(210, 35));
        logo.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("STUDENT PORTAL");
        subtitle.setFont(new Font("Arial", Font.BOLD, 10));
        subtitle.setForeground(new Color(160, 180, 205));

        top.add(logo);
        top.add(Box.createVerticalStrut(5));
        top.add(subtitle);
        top.add(Box.createVerticalStrut(45));

        JLabel menuLabel = new JLabel("MAIN MENU");
        menuLabel.setFont(new Font("Arial", Font.BOLD, 11));
        menuLabel.setForeground(new Color(150, 170, 195));

        top.add(menuLabel);
        top.add(Box.createVerticalStrut(15));

        addSidebarItem(top, "Dashboard", "⌂", true, () -> {
            JOptionPane.showMessageDialog(
                this, "You are in Student Dashboard."
            );
        });

        addSidebarItem(top, "Request Document", "+", false,
            () -> openRequestDocument());

        addSidebarItem(top, "My Requests", "▤", false,
            () -> openMyRequests());

        addSidebarItem(top, "Notifications", "●", false,
            () -> openNotifications());

        addSidebarItem(top, "My Profile", "◉", false,
            () -> openProfile());

        JPanel bottom = new JPanel();
        bottom.setBackground(sidebarColor);
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setBorder(new EmptyBorder(15, 20, 25, 20));

        JLabel portalInfo = new JLabel("College Document Portal");
        portalInfo.setFont(new Font("Arial", Font.PLAIN, 12));
        portalInfo.setForeground(new Color(175, 190, 210));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setMaximumSize(new Dimension(190, 42));
        logoutButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setBackground(new Color(55, 75, 105));
        logoutButton.setFocusPainted(false);
        logoutButton.setBorderPainted(false);
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        logoutButton.addActionListener(e -> {

            int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to logout?",
                "Logout",
                JOptionPane.YES_NO_OPTION
            );

            if (choice == JOptionPane.YES_OPTION) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });

        bottom.add(portalInfo);
        bottom.add(Box.createVerticalStrut(18));
        bottom.add(logoutButton);

        sidebar.add(top, BorderLayout.CENTER);
        sidebar.add(bottom, BorderLayout.SOUTH);

        return sidebar;
    }

    private void addSidebarItem(
        JPanel panel,
        String name,
        String symbol,
        boolean selected,
        Runnable action
    ) {

        JPanel item = new JPanel(new BorderLayout(12, 0));
        item.setMaximumSize(new Dimension(205, 45));
        item.setPreferredSize(new Dimension(205, 45));

        item.setBackground(
            selected ? new Color(55, 91, 137) : sidebarColor
        );

        item.setBorder(new EmptyBorder(8, 12, 8, 10));
        item.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel icon = new JLabel(symbol);
        icon.setFont(new Font("Arial", Font.BOLD, 17));
        icon.setForeground(Color.WHITE);

        JLabel label = new JLabel(name);
        label.setFont(new Font("Arial", Font.BOLD, 13));
        label.setForeground(Color.WHITE);

        item.add(icon, BorderLayout.WEST);
        item.add(label, BorderLayout.CENTER);

        item.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                action.run();
            }

            public void mouseEntered(MouseEvent e) {
                if (!selected) {
                    item.setBackground(new Color(40, 62, 91));
                }
            }

            public void mouseExited(MouseEvent e) {
                if (!selected) {
                    item.setBackground(sidebarColor);
                }
            }
        });

        panel.add(item);
        panel.add(Box.createVerticalStrut(8));
    }

    private JPanel createMainContent() {

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(background);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(18, 35, 18, 35));

        JPanel headerText = new JPanel();
        headerText.setLayout(new BoxLayout(headerText, BoxLayout.Y_AXIS));
        headerText.setBackground(Color.WHITE);

        JLabel title = new JLabel("Student Dashboard");
        title.setFont(new Font("Arial", Font.BOLD, 23));
        title.setForeground(textColor);

        JLabel subTitle = new JLabel(
            "Manage your document requests and updates"
        );
        subTitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subTitle.setForeground(mutedColor);

        headerText.add(title);
        headerText.add(Box.createVerticalStrut(5));
        headerText.add(subTitle);

        JLabel studentLabel = new JLabel(
            "Welcome, " + studentName + "   "
        );
        studentLabel.setFont(new Font("Arial", Font.BOLD, 14));
        studentLabel.setForeground(primaryColor);

        header.add(headerText, BorderLayout.WEST);
        header.add(studentLabel, BorderLayout.EAST);

        JPanel content = new JPanel();
        content.setBackground(background);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(30, 35, 30, 35));

        // Welcome Banner with College Image

        JPanel welcome = new JPanel(new BorderLayout(20, 0));
        welcome.setBackground(new Color(225, 238, 253));
        welcome.setBorder(new EmptyBorder(20, 25, 20, 20));
        welcome.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));
        welcome.setPreferredSize(new Dimension(900, 160));

        JPanel welcomeText = new JPanel();
        welcomeText.setBackground(new Color(225, 238, 253));
        welcomeText.setLayout(new BoxLayout(welcomeText, BoxLayout.Y_AXIS));

        JLabel welcomeTitle = new JLabel("Welcome to DocuFlow!");
        welcomeTitle.setFont(new Font("Arial", Font.BOLD, 27));
        welcomeTitle.setForeground(new Color(24, 43, 69));

        JLabel welcomeMessage = new JLabel(
            "<html>Manage your college documents easily,<br>quickly and securely.</html>"
        );
        welcomeMessage.setFont(new Font("Arial", Font.PLAIN, 16));
        welcomeMessage.setForeground(new Color(55, 75, 105));

        JButton requestButton = new JButton("Request a Document");
        requestButton.setFont(new Font("Arial", Font.BOLD, 13));
        requestButton.setForeground(Color.WHITE);
        requestButton.setBackground(primaryColor);
        requestButton.setFocusPainted(false);
        requestButton.setBorder(new EmptyBorder(10, 18, 10, 18));
        requestButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        requestButton.addActionListener(e -> openRequestDocument());

        welcomeText.add(welcomeTitle);
        welcomeText.add(Box.createVerticalStrut(12));
        welcomeText.add(welcomeMessage);
        welcomeText.add(Box.createVerticalStrut(15));
        welcomeText.add(requestButton);

        URL imageURL = getClass().getResource(
            "/images/mepco.jpg"
        );

        if (imageURL != null) {

            ImageIcon originalImage = new ImageIcon(imageURL);

            Image scaledImage = originalImage.getImage()
                .getScaledInstance(400, 140, Image.SCALE_SMOOTH);

            JLabel collegeImage = new JLabel(
                new ImageIcon(scaledImage)
            );

            welcome.add(collegeImage, BorderLayout.EAST);

        } else {

            JLabel imageError = new JLabel("College Image");
            imageError.setForeground(primaryColor);
            welcome.add(imageError, BorderLayout.EAST);
        }

        welcome.add(welcomeText, BorderLayout.CENTER);

        // Quick Access Heading

        JLabel quickHeading = new JLabel("Quick Access");
        quickHeading.setFont(new Font("Arial", Font.BOLD, 20));
        quickHeading.setForeground(textColor);
        quickHeading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel quickSubheading = new JLabel(
            "Choose a service to continue"
        );
        quickSubheading.setFont(new Font("Arial", Font.PLAIN, 13));
        quickSubheading.setForeground(mutedColor);
        quickSubheading.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Quick Access Cards

        JPanel cards = new JPanel(new GridLayout(2, 2, 18, 18));
        cards.setBackground(background);
        cards.setMaximumSize(new Dimension(Integer.MAX_VALUE, 285));

        cards.add(createActionCard(
            "Request Document",
            "Submit a new college document request",
            "+",
            () -> openRequestDocument()
        ));

        cards.add(createActionCard(
            "My Requests",
            "View and track your document requests",
            "▤",
            () -> openMyRequests()
        ));

        notificationCard = createActionCard(
            "Notifications",
            "View important updates and messages",
            "●",
            () -> openNotifications()
        );

        unreadBadge = new JLabel("0");
        unreadBadge.setFont(new Font("Arial", Font.BOLD, 11));
        unreadBadge.setForeground(Color.WHITE);
        unreadBadge.setBackground(new Color(220, 55, 65));
        unreadBadge.setOpaque(true);
        unreadBadge.setHorizontalAlignment(SwingConstants.CENTER);
        unreadBadge.setPreferredSize(new Dimension(25, 25));
        unreadBadge.setBorder(new EmptyBorder(3, 5, 3, 5));
        unreadBadge.setVisible(false);

        JPanel notificationWrapper = new JPanel(new BorderLayout());
        notificationWrapper.setBackground(Color.WHITE);
        notificationWrapper.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor),
                new EmptyBorder(18, 18, 18, 18)
            )
        );

        notificationWrapper.add(notificationCard, BorderLayout.CENTER);
        notificationWrapper.add(unreadBadge, BorderLayout.NORTH);

        notificationWrapper.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );

        notificationWrapper.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                openNotifications();
            }
        });

        cards.add(notificationWrapper);

        cards.add(createActionCard(
            "My Profile",
            "View your student account details",
            "◉",
            () -> openProfile()
        ));

        // Recent Activity

        JLabel recentHeading = new JLabel("Recent Activity");
        recentHeading.setFont(new Font("Arial", Font.BOLD, 19));
        recentHeading.setForeground(textColor);
        recentHeading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel recentPanel = new JPanel(new BorderLayout());
        recentPanel.setBackground(Color.WHITE);
        recentPanel.setBorder(
            new CompoundBorder(
                BorderFactory.createLineBorder(borderColor),
                new EmptyBorder(18, 20, 18, 20)
            )
        );

        recentPanel.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 75)
        );

        JLabel recentText = new JLabel(
            "Your recent document request activity will appear here."
        );
        recentText.setFont(new Font("Arial", Font.PLAIN, 13));
        recentText.setForeground(mutedColor);

        recentPanel.add(recentText, BorderLayout.CENTER);

        content.add(welcome);
        content.add(Box.createVerticalStrut(28));
        content.add(quickHeading);
        content.add(Box.createVerticalStrut(6));
        content.add(quickSubheading);
        content.add(Box.createVerticalStrut(18));
        content.add(cards);
        content.add(Box.createVerticalStrut(28));
        content.add(recentHeading);
        content.add(Box.createVerticalStrut(14));
        content.add(recentPanel);

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(background);

        JPanel topArea = new JPanel();
        topArea.setLayout(new BoxLayout(topArea, BoxLayout.Y_AXIS));
        topArea.setBackground(Color.WHITE);

        notificationBanner = createCollectionNotificationBanner();
        notificationBanner.setVisible(false);
        notificationBanner.setPreferredSize(new Dimension(900, 0));
        notificationBanner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 0));

        topArea.add(header);
        topArea.add(notificationBanner);

        main.add(topArea, BorderLayout.NORTH);
        main.add(scrollPane, BorderLayout.CENTER);

        return main;
    }

    private JPanel createActionCard(
        String title,
        String description,
        String symbol,
        Runnable action
    ) {

        JPanel card = new JPanel(new BorderLayout(12, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(
            new CompoundBorder(
                BorderFactory.createLineBorder(borderColor),
                new EmptyBorder(18, 18, 18, 18)
            )
        );

        JPanel iconPanel = new JPanel(new BorderLayout());
        iconPanel.setPreferredSize(new Dimension(43, 43));
        iconPanel.setBackground(new Color(232, 241, 252));

        JLabel icon = new JLabel(symbol, SwingConstants.CENTER);
        icon.setFont(new Font("Arial", Font.BOLD, 23));
        icon.setForeground(primaryColor);

        iconPanel.add(icon, BorderLayout.CENTER);

        JPanel textPanel = new JPanel();
        textPanel.setBackground(Color.WHITE);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel(title);
        heading.setFont(new Font("Arial", Font.BOLD, 16));
        heading.setForeground(textColor);

        JLabel detail = new JLabel(description);
        detail.setFont(new Font("Arial", Font.PLAIN, 12));
        detail.setForeground(mutedColor);

        JLabel arrow = new JLabel("Open  →");
        arrow.setFont(new Font("Arial", Font.BOLD, 12));
        arrow.setForeground(primaryColor);

        textPanel.add(heading);
        textPanel.add(Box.createVerticalStrut(7));
        textPanel.add(detail);
        textPanel.add(Box.createVerticalStrut(12));
        textPanel.add(arrow);

        card.add(iconPanel, BorderLayout.WEST);
        card.add(textPanel, BorderLayout.CENTER);

        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        card.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                action.run();
            }

            public void mouseEntered(MouseEvent e) {
                card.setBorder(
                    new CompoundBorder(
                        BorderFactory.createLineBorder(primaryColor, 2),
                        new EmptyBorder(17, 17, 17, 17)
                    )
                );
            }

            public void mouseExited(MouseEvent e) {
                card.setBorder(
                    new CompoundBorder(
                        BorderFactory.createLineBorder(borderColor),
                        new EmptyBorder(18, 18, 18, 18)
                    )
                );
            }
        });

        return card;
    }

    private void refreshUnreadCount() {

        try {

            Connection con = DBConnection.getConnection();

            String query =
                "SELECT COUNT(*) FROM NOTIFICATION n " +
                "JOIN STUDENT s ON n.STUDENT_ID = s.STUDENT_ID " +
                "WHERE s.USER_ID = ? AND n.IS_READ = 'N'";

            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, userId);

            ResultSet rs = ps.executeQuery();

            int count = 0;

            if (rs.next()) {
                count = rs.getInt(1);
            }

            unreadBadge.setText(
                count > 99 ? "99+" : String.valueOf(count)
            );

            unreadBadge.setVisible(count > 0);

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Check for collection-ready notifications when the dashboard opens
    // and every 10 seconds while the dashboard remains open.
    private void startCollectionNotificationChecker() {

        checkCollectionNotifications();

        collectionNotificationTimer = new javax.swing.Timer(
            10000,
            e -> checkCollectionNotifications()
        );

        collectionNotificationTimer.start();
    }

    // Create the coloured notification banner shown below the dashboard header.
    private JPanel createCollectionNotificationBanner() {

        JPanel banner = new JPanel(new BorderLayout(15, 5));
        banner.setBackground(new Color(225, 240, 255));
        banner.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(
                    0, 0, 2, 0, new Color(65, 135, 205)
                ),
                new EmptyBorder(12, 22, 12, 18)
            )
        );

        JPanel messagePanel = new JPanel();
        messagePanel.setBackground(new Color(225, 240, 255));
        messagePanel.setLayout(new BoxLayout(messagePanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("DOCUMENT READY FOR COLLECTION");
        heading.setFont(new Font("Arial", Font.BOLD, 13));
        heading.setForeground(new Color(25, 85, 145));

        bannerMessageLabel = new JLabel(
            "Your document is ready for collection."
        );
        bannerMessageLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        bannerMessageLabel.setForeground(new Color(40, 55, 75));

        messagePanel.add(heading);
        messagePanel.add(Box.createVerticalStrut(5));
        messagePanel.add(bannerMessageLabel);

        JButton closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 22));
        closeButton.setForeground(new Color(55, 85, 115));
        closeButton.setBackground(new Color(225, 240, 255));
        closeButton.setBorderPainted(false);
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeButton.addActionListener(e -> dismissCollectionBanner());

        banner.add(messagePanel, BorderLayout.CENTER);
        banner.add(closeButton, BorderLayout.EAST);

        return banner;
    }

    private void checkCollectionNotifications() {

        if (bannerVisible) {
            return;
        }

        String sql =
            "SELECT n.NOTIFICATION_ID, n.MESSAGE " +
            "FROM NOTIFICATION n " +
            "JOIN STUDENT s ON n.STUDENT_ID = s.STUDENT_ID " +
            "WHERE s.USER_ID = ? " +
            "AND LOWER(n.MESSAGE) LIKE '%ready for collection%' " +
            "AND NVL(n.POPUP_SHOWN, 'N') = 'N' " +
            "ORDER BY n.NOTIFICATION_DATE ASC";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, userId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    currentNotificationId =
                        rs.getInt("NOTIFICATION_ID");

                    String message = rs.getString("MESSAGE");

                    bannerMessageLabel.setText(
                        "<html>" + escapeHtml(
                            message == null
                                ? "Your document is ready for collection."
                                : message
                        ) + "</html>"
                    );

                    showCollectionBanner();
                }
            }

        } catch (Exception e) {
            System.out.println(
                "Unable to check collection notifications: " + e.getMessage()
            );
        }
    }

    private String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");
    }

    // Slide the banner down from the top of the dashboard.
    private void showCollectionBanner() {

        if (bannerVisible) {
            return;
        }

        bannerVisible = true;
        bannerHeight = 0;
        notificationBanner.setVisible(true);

        if (bannerAnimationTimer != null) {
            bannerAnimationTimer.stop();
        }

        bannerAnimationTimer = new javax.swing.Timer(12, e -> {

            bannerHeight += 8;

            if (bannerHeight >= 82) {
                bannerHeight = 82;
                bannerAnimationTimer.stop();
            }

            notificationBanner.setPreferredSize(
                new Dimension(notificationBanner.getWidth(), bannerHeight)
            );
            notificationBanner.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, bannerHeight)
            );

            notificationBanner.revalidate();
            notificationBanner.repaint();
        });

        bannerAnimationTimer.start();
    }

    // The × button dismisses only the banner.
    // The notification remains unread in the Notifications page.
    private void dismissCollectionBanner() {

        if (currentNotificationId == -1) {
            hideCollectionBanner();
            return;
        }

        String sql =
            "UPDATE NOTIFICATION SET POPUP_SHOWN = 'Y' " +
            "WHERE NOTIFICATION_ID = ? " +
            "AND STUDENT_ID IN " +
            "(SELECT STUDENT_ID FROM STUDENT WHERE USER_ID = ?)";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, currentNotificationId);
            ps.setString(2, userId);
            ps.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                this,
                "Unable to dismiss notification. Please try again.",
                "Notification",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        hideCollectionBanner();

        currentNotificationId = -1;

        // Check whether another collection-ready notification is waiting.
        javax.swing.Timer nextNotificationTimer =
            new javax.swing.Timer(250, e -> {
                ((javax.swing.Timer) e.getSource()).stop();
                checkCollectionNotifications();
            });

        nextNotificationTimer.setRepeats(false);
        nextNotificationTimer.start();
    }

    private void hideCollectionBanner() {

        if (bannerAnimationTimer != null) {
            bannerAnimationTimer.stop();
        }

        bannerHeight = 0;
        bannerVisible = false;
        notificationBanner.setPreferredSize(
            new Dimension(notificationBanner.getWidth(), 0)
        );
        notificationBanner.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 0)
        );
        notificationBanner.setVisible(false);
        notificationBanner.revalidate();
        notificationBanner.repaint();
    }

    private void openRequestDocument() {

        RequestDocument form = new RequestDocument(userId);
        form.setVisible(true);
    }

    private void openMyRequests() {

        MyRequests page = new MyRequests(userId);
        page.setVisible(true);
    }

    private void openNotifications() {

        Notifications page = new Notifications(userId);

        page.addWindowListener(new WindowAdapter() {
            public void windowClosed(WindowEvent e) {
                refreshUnreadCount();
            }
        });

        page.setVisible(true);
    }

    private void openProfile() {

        ProfilePage page = new ProfilePage(userId);
        page.setVisible(true);
    }
}
