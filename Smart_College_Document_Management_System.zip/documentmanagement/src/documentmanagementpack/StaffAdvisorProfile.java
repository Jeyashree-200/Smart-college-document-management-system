package documentmanagementpack;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class StaffAdvisorProfile extends JFrame {

    private final Color darkBlue = new Color(18, 42, 91);
    private final Color royalBlue = new Color(42, 103, 205);
    private final Color lightBlue = new Color(225, 236, 255);
    private final Color pageBackground = new Color(246, 248, 253);

    public StaffAdvisorProfile(
        String advisorName,
        String advisorId,
        String department,
        String section,
        String userId
    ) {
        setTitle("DocuFlow - Staff Advisor Profile");
        setSize(1050, 680);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(pageBackground);

        // LEFT SIDE - STUDY DESK IMAGE AND DOCUFLOW BRANDING
        ImagePanel leftPanel = new ImagePanel();
        leftPanel.setPreferredSize(new Dimension(330, 650));
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(35, 28, 30, 25));

        JLabel logo = new JLabel("DOCUFLOW");
        logo.setFont(new Font("Arial", Font.BOLD, 30));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tagline = new JLabel("Smart Document Management");
        tagline.setFont(new Font("Arial", Font.ITALIC, 15));
        tagline.setForeground(new Color(225, 235, 255));
        tagline.setAlignmentX(Component.LEFT_ALIGNMENT);

        JSeparator separator = new JSeparator();
        separator.setForeground(new Color(130, 180, 245));
        separator.setMaximumSize(new Dimension(260, 2));
        separator.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel profileTitle = new JLabel("My Profile");
        profileTitle.setFont(new Font("Georgia", Font.BOLD, 34));
        profileTitle.setForeground(Color.WHITE);
        profileTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel roleTitle = new JLabel("Staff Advisor Account");
        roleTitle.setFont(new Font("Georgia", Font.ITALIC, 17));
        roleTitle.setForeground(new Color(235, 240, 255));
        roleTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        leftPanel.add(logo);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(tagline);
        leftPanel.add(Box.createVerticalStrut(28));
        leftPanel.add(separator);
        leftPanel.add(Box.createVerticalStrut(45));
        leftPanel.add(profileTitle);
        leftPanel.add(Box.createVerticalStrut(12));
        leftPanel.add(roleTitle);
        leftPanel.add(Box.createVerticalGlue());

        JLabel leftFooter = new JLabel("A smarter way to manage documents");
        leftFooter.setFont(new Font("Arial", Font.PLAIN, 12));
        leftFooter.setForeground(Color.WHITE);
        leftFooter.setAlignmentX(Component.LEFT_ALIGNMENT);
        leftPanel.add(leftFooter);

        // RIGHT SIDE CONTENT
        JPanel rightPanel = new JPanel(new BorderLayout(20, 20));
        rightPanel.setBackground(pageBackground);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(35, 35, 28, 35));

        JPanel headingPanel = new JPanel();
        headingPanel.setBackground(darkBlue);
        headingPanel.setLayout(new BorderLayout());
        headingPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JLabel heading = new JLabel("STAFF ADVISOR DETAILS");
        heading.setFont(new Font("Arial", Font.BOLD, 23));
        heading.setForeground(Color.WHITE);
        headingPanel.add(heading, BorderLayout.CENTER);

        JPanel profileCard = new JPanel();
        profileCard.setBackground(Color.WHITE);
        profileCard.setLayout(new BoxLayout(profileCard, BoxLayout.Y_AXIS));
        profileCard.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(220, 228, 242), 1, true),
            BorderFactory.createEmptyBorder(28, 30, 28, 30)
        ));

        JLabel nameLabel = new JLabel(safe(advisorName));
        nameLabel.setFont(new Font("Georgia", Font.BOLD, 29));
        nameLabel.setForeground(darkBlue);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel roleLabel = new JLabel("Staff Advisor");
        roleLabel.setFont(new Font("Arial", Font.ITALIC, 17));
        roleLabel.setForeground(royalBlue);
        roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JSeparator goldLine = new JSeparator();
        goldLine.setForeground(new Color(220, 170, 65));
        goldLine.setMaximumSize(new Dimension(Integer.MAX_VALUE, 2));
        goldLine.setAlignmentX(Component.LEFT_ALIGNMENT);

        profileCard.add(nameLabel);
        profileCard.add(Box.createVerticalStrut(7));
        profileCard.add(roleLabel);
        profileCard.add(Box.createVerticalStrut(22));
        profileCard.add(goldLine);
        profileCard.add(Box.createVerticalStrut(25));

        addDetailRow(profileCard, "Advisor ID", safe(advisorId));
        addDetailRow(profileCard, "Department", safe(department));
        addDetailRow(profileCard, "Section", safe(section));
        addDetailRow(profileCard, "User ID", safe(userId));
        addDetailRow(profileCard, "Role", "Staff Advisor");

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(pageBackground);

        JLabel footer = new JLabel(
            "Together for a Better Academic Journey",
            SwingConstants.CENTER
        );
        footer.setFont(new Font("Georgia", Font.ITALIC, 17));
        footer.setForeground(darkBlue);
        footer.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(195, 216, 250), 1, true),
            BorderFactory.createEmptyBorder(14, 10, 14, 10)
        ));
        footer.setOpaque(true);
        footer.setBackground(lightBlue);

        JButton backButton = new JButton("Back to Dashboard");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(darkBlue);
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backButton.setPreferredSize(new Dimension(190, 43));
        backButton.addActionListener(e -> dispose());

        JPanel buttonHolder = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonHolder.setBackground(pageBackground);
        buttonHolder.add(backButton);

        bottomPanel.add(footer, BorderLayout.NORTH);
        bottomPanel.add(buttonHolder, BorderLayout.SOUTH);

        rightPanel.add(headingPanel, BorderLayout.NORTH);
        rightPanel.add(profileCard, BorderLayout.CENTER);
        rightPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(leftPanel, BorderLayout.WEST);
        mainPanel.add(rightPanel, BorderLayout.CENTER);
        setContentPane(mainPanel);
    }

    private void addDetailRow(JPanel panel, String label, String value) {
        JPanel row = new JPanel(new GridLayout(1, 2, 15, 0));
        row.setBackground(Color.WHITE);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 53));
        row.setPreferredSize(new Dimension(600, 53));
        row.setBorder(BorderFactory.createEmptyBorder(5, 8, 5, 8));

        JLabel labelText = new JLabel(label);
        labelText.setFont(new Font("Arial", Font.BOLD, 15));
        labelText.setForeground(new Color(55, 75, 115));

        JLabel valueText = new JLabel(value);
        valueText.setFont(new Font("Arial", Font.BOLD, 16));
        valueText.setForeground(darkBlue);

        row.add(labelText);
        row.add(valueText);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(row);
        panel.add(Box.createVerticalStrut(8));
    }

    private String safe(String value) {
        return value == null || value.trim().isEmpty() ? "Not assigned" : value;
    }

    private class ImagePanel extends JPanel {
        private BufferedImage backgroundImage;

        ImagePanel() {
            try {
                backgroundImage = ImageIO.read(
                    StaffAdvisorProfile.class.getResource(
                        "/documentmanagementpack/images/study_desk.jpg"
                    )
                );
            } catch (Exception e) {
                backgroundImage = null;
            }
            setOpaque(true);
            setBackground(darkBlue);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            if (backgroundImage != null) {
                g2.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
            g2.setColor(new Color(8, 28, 68, 185));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(new Color(70, 135, 225));
            g2.fillRect(getWidth() - 5, 0, 5, getHeight());
            g2.dispose();
        }
    }
}
