/**
 * 
 */
/**
 * 
 */
module documentmanagement {
	requires java.desktop;
	requires java.sql;
	requires java.prefs;
}