
package documentmanagementpack;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StaffAdvisorNotifications extends JFrame {

    String userId;

    Color darkBlue = new Color(25, 42, 86);
    Color lightBackground = new Color(245, 247, 252);
    Color blue = new Color(55, 100, 210);

    JTable notificationTable;
    DefaultTableModel model;

    public StaffAdvisorNotifications(String userId) {

        this.userId = userId;

        setTitle("DocuFlow - Notifications");
        setSize(1000, 550);
        setMinimumSize(new Dimension(850, 450));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        getContentPane().setBackground(lightBackground);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(darkBlue);
        headerPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel heading = new JLabel("Notifications");
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setForeground(Color.WHITE);

        JLabel subHeading = new JLabel(
            "View student request updates and approval notifications"
        );
        subHeading.setFont(new Font("Arial", Font.PLAIN, 13));
        subHeading.setForeground(Color.WHITE);

        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(darkBlue);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));

        titlePanel.add(heading);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(subHeading);

        headerPanel.add(titlePanel, BorderLayout.WEST);

        add(headerPanel, BorderLayout.NORTH);

        String[] columns = {
            "Notification ID",
            "Request ID",
            "Student Name",
            "Roll Number",
            "Message",
            "Date",
            "Status"
        };

        model = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        notificationTable = new JTable(model);
        notificationTable.setRowHeight(35);
        notificationTable.setFont(new Font("Arial", Font.PLAIN, 13));
        notificationTable.setSelectionBackground(
            new Color(220, 230, 250)
        );
        notificationTable.setSelectionForeground(Color.BLACK);
        notificationTable.setShowVerticalLines(false);
        notificationTable.setAutoResizeMode(
            JTable.AUTO_RESIZE_OFF
        );

        notificationTable.getColumnModel()
            .getColumn(0).setPreferredWidth(100);
        notificationTable.getColumnModel()
            .getColumn(1).setPreferredWidth(90);
        notificationTable.getColumnModel()
            .getColumn(2).setPreferredWidth(140);
        notificationTable.getColumnModel()
            .getColumn(3).setPreferredWidth(110);
        notificationTable.getColumnModel()
            .getColumn(4).setPreferredWidth(350);
        notificationTable.getColumnModel()
            .getColumn(5).setPreferredWidth(150);
        notificationTable.getColumnModel()
            .getColumn(6).setPreferredWidth(80);

        //JTableHeader tableHeader =
           // notificationTable.getTableHeader();
        JTableHeader tableHeader =
        	    notificationTable.getTableHeader();

        	tableHeader.setDefaultRenderer(new DefaultTableCellRenderer() {

        	    @Override
        	    public Component getTableCellRendererComponent(
        	        JTable table, Object value, boolean isSelected,
        	        boolean hasFocus, int row, int column) {

        	        JLabel label = (JLabel) super.getTableCellRendererComponent(
        	            table, value, isSelected, hasFocus, row, column
        	        );

        	        label.setBackground(darkBlue);
        	        label.setForeground(Color.WHITE);
        	        label.setFont(new Font("Arial", Font.BOLD, 14));
        	        label.setHorizontalAlignment(SwingConstants.CENTER);
        	        label.setOpaque(true);

        	        return label;
        	    }
        	});

        	tableHeader.setPreferredSize(new Dimension(0, 45));
        	tableHeader.setReorderingAllowed(false);
        JScrollPane scrollPane =
            new JScrollPane(notificationTable);

        scrollPane.setBorder(
            BorderFactory.createEmptyBorder()
        );

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        tablePanel.add(scrollPane, BorderLayout.CENTER);

        add(tablePanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 12, 12)
        );
        bottomPanel.setBackground(lightBackground);

        JButton refreshButton = new JButton("Refresh");
        JButton closeButton = new JButton("Close");

        styleButton(refreshButton, blue);
        styleButton(closeButton, darkBlue);

        bottomPanel.add(refreshButton);
        bottomPanel.add(closeButton);

        add(bottomPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> loadNotifications());

        closeButton.addActionListener(e -> dispose());

        notificationTable.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                if (e.getClickCount() == 2) {
                    viewNotification();
                }
            }
        });

        loadNotifications();
    }

    private void styleButton(JButton button, Color color) {

        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(110, 38));
    }

    private void loadNotifications() {

        model.setRowCount(0);

        String sql =
            "SELECT n.notification_id, n.request_id, " +
            "u.name AS student_name, s.student_id, " +
            "n.message, n.notification_date, n.is_read " +
            "FROM NOTIFICATION n " +
            "JOIN DOCUMENT_REQUEST dr " +
            "ON n.request_id = dr.request_id " +
            "JOIN STUDENT s " +
            "ON dr.student_id = s.student_id " +
            "JOIN USERS u " +
            "ON s.user_id = u.user_id " +
            "WHERE n.recipient_user_id = ? " +
            "ORDER BY n.notification_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(userId));

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    String status =
                        rs.getString("is_read");

                    String displayStatus =
                        "Y".equalsIgnoreCase(status)
                        ? "Read" : "Unread";

                    model.addRow(new Object[] {
                        rs.getString("notification_id"),
                        rs.getString("request_id"),
                        rs.getString("student_name"),
                        rs.getString("student_id"),
                        rs.getString("message"),
                        rs.getString("notification_date"),
                        displayStatus
                    });
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(this,
                "Error loading notifications: " + e.getMessage());
        }
    }

    private void viewNotification() {

        int selectedRow =
            notificationTable.getSelectedRow();

        if (selectedRow == -1) {
            return;
        }

        String notificationId =
            model.getValueAt(selectedRow, 0).toString();

        String requestId =
            model.getValueAt(selectedRow, 1).toString();

        String studentName =
            model.getValueAt(selectedRow, 2).toString();

        String rollNumber =
            model.getValueAt(selectedRow, 3).toString();

        String message =
            model.getValueAt(selectedRow, 4).toString();

        String date =
            model.getValueAt(selectedRow, 5).toString();

        updateReadStatus(notificationId);

        JOptionPane.showMessageDialog(this,
            "Request ID: " + requestId +
            "\nStudent Name: " + studentName +
            "\nRoll Number: " + rollNumber +
            "\n\nMessage: " + message +
            "\n\nDate: " + date,
            "Notification Details",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void updateReadStatus(String notificationId) {

        String sql =
            "UPDATE NOTIFICATION SET is_read = 'Y' " +
            "WHERE notification_id = ? " +
            "AND recipient_user_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(notificationId));
            ps.setInt(2, Integer.parseInt(userId));

            ps.executeUpdate();

            loadNotifications();

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(this,
                "Error updating notification: " + e.getMessage());
        }
    }
}
