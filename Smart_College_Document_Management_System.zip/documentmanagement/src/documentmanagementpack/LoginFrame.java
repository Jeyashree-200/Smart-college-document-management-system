
package documentmanagementpack;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.sql.*;

public class LoginFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField email;
    private JPasswordField password;

    private final Color navy = new Color(20, 45, 80);
    private final Color blue = new Color(39, 91, 155);
    private final Color lightGray = new Color(245, 247, 250);

    public LoginFrame() {

        setTitle("DocuFlow - Login");
        setSize(1050, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(1, 2));

        add(createLeftPanel());
        add(createRightPanel());

        setVisible(true);
    }

    private JPanel createLeftPanel() {

        CollegeBackgroundPanel panel = new CollegeBackgroundPanel();
        panel.setLayout(new BorderLayout());

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(
            BorderFactory.createEmptyBorder(170, 35, 30, 35)
        );

        //JLabel title = new JLabel("DocuFlow");
        //title.setFont(new Font("Arial", Font.BOLD, 48));
        //title.setForeground(Color.WHITE);
        //title.setAlignmentX(Component.CENTER_ALIGNMENT);


JLabel subtitle = new JLabel(
    "<html><center>Smart College Document<br>" +
    "Management System</center></html>"
);

subtitle.setFont(new Font("Arial", Font.BOLD, 32));
subtitle.setForeground(Color.WHITE);
subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel message = new JLabel(
            "<html><center>Simple • Secure • Smart<br>" +
            "Manage your document requests easily.</center></html>"
        );

        //message.setFont(new Font("Arial", Font.PLAIN, 15));
        message.setFont(new Font("Arial", Font.PLAIN, 18));
        message.setForeground(new Color(225, 235, 245));
        message.setAlignmentX(Component.CENTER_ALIGNMENT);

        /*content.add(title);
        content.add(Box.createVerticalStrut(20));*/
        content.add(subtitle);
        content.add(Box.createVerticalStrut(30));
        content.add(message);

        panel.add(content, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createRightPanel() {

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(lightGray);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);

        formPanel.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(225, 230, 238)
                ),
                BorderFactory.createEmptyBorder(35, 40, 35, 40)
            )
        );

        formPanel.setPreferredSize(new Dimension(390, 440));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(8, 0, 8, 0);

        JLabel heading = new JLabel("Welcome Back!");
        heading.setFont(new Font("Arial", Font.BOLD, 30));
        heading.setForeground(navy);
        heading.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel description = new JLabel("Login to your account");
        description.setFont(new Font("Arial", Font.PLAIN, 16));
        description.setForeground(Color.GRAY);
        description.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel emailLabel = new JLabel("Email Address");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 15));
        emailLabel.setForeground(navy);

        email = new JTextField();
        styleField(email);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 15));
        passwordLabel.setForeground(navy);

        password = new JPasswordField();
        styleField(password);

        JButton loginButton = new JButton("Login");
        styleButton(loginButton, blue, Color.WHITE);

        JButton signUpButton = new JButton("Create New Account");
        styleButton(signUpButton, Color.WHITE, navy);

        signUpButton.setBorder(
            BorderFactory.createLineBorder(
                new Color(210, 218, 230)
            )
        );

        gbc.gridy = 0;
        formPanel.add(heading, gbc);

        gbc.gridy = 1;
        gbc.insets = new Insets(5, 0, 25, 0);
        formPanel.add(description, gbc);

        gbc.insets = new Insets(8, 0, 5, 0);
        gbc.gridy = 2;
        formPanel.add(emailLabel, gbc);

        gbc.gridy = 3;
        gbc.insets = new Insets(5, 0, 15, 0);
        formPanel.add(email, gbc);

        gbc.insets = new Insets(8, 0, 5, 0);
        gbc.gridy = 4;
        formPanel.add(passwordLabel, gbc);

        gbc.gridy = 5;
        gbc.insets = new Insets(5, 0, 20, 0);
        formPanel.add(password, gbc);

        gbc.gridy = 6;
        gbc.insets = new Insets(5, 0, 10, 0);
        formPanel.add(loginButton, gbc);

        gbc.gridy = 7;
        gbc.insets = new Insets(5, 0, 5, 0);
        formPanel.add(signUpButton, gbc);

        GridBagConstraints outer = new GridBagConstraints();
        outer.gridx = 0;
        outer.gridy = 0;

        panel.add(formPanel, outer);

        loginButton.addActionListener(e -> loginUser());

        password.addActionListener(e -> loginUser());

        signUpButton.addActionListener(e -> {
            dispose();
            new RegisterFrame().setVisible(true);
        });

        return panel;
    }

    private void styleField(JTextField field) {

        field.setFont(new Font("Arial", Font.PLAIN, 16));
        field.setPreferredSize(new Dimension(300, 45));
        field.setBackground(new Color(250, 251, 253));

        field.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(215, 222, 232)
                ),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
            )
        );
    }

    private void styleButton(
        JButton button, Color background, Color foreground
    ) {

        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(foreground);
        button.setBackground(background);
        button.setPreferredSize(new Dimension(300, 45));
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setUI(new BasicButtonUI());
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loginUser() {

        String userEmail = email.getText().trim();
        String userPassword = new String(password.getPassword());

        if (userEmail.isEmpty() || userPassword.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please enter email and password."
            );

            return;
        }

        String query =
            "SELECT user_id, name, role FROM USERS " +
            "WHERE email = ? AND password = ? " +
            "AND (is_active = 'Y' OR is_active = '1')";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query)
        ) {

            ps.setString(1, userEmail);
            ps.setString(2, userPassword);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    String userId = rs.getString("user_id");
                    String name = rs.getString("name");
                    String role = rs.getString("role");

                    JOptionPane.showMessageDialog(
                        this,
                        "Welcome, " + name + "!"
                    );

                    if (role.equalsIgnoreCase("STUDENT")) {

                        new StudentDashboard(name, userId).setVisible(true);

                    } else if (role.equalsIgnoreCase("STAFF_ADVISOR")) {

                        new StaffAdvisorDashboard(name, userId).setVisible(true);

                    } else if (role.equalsIgnoreCase("HOD")) {

                        new HODDashboard(name, userId).setVisible(true);

                    } else if (role.equalsIgnoreCase("ADMIN")) {

                        new AdminDashboard(userId).setVisible(true);

                    } else {

                        JOptionPane.showMessageDialog(
                            this,
                            "Invalid user role: " + role
                        );

                        return;
                    }

                    dispose();

                } else {

                    JOptionPane.showMessageDialog(
                        this,
                        "Invalid email or password."
                    );
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Database Error: " + ex.getMessage()
            );
        }
    }

    private class CollegeBackgroundPanel extends JPanel {

        private static final long serialVersionUID = 1L;

        private Image backgroundImage;

        public CollegeBackgroundPanel() {

            java.net.URL imageURL =
                LoginFrame.class.getResource("/images/college.png.png");

            if (imageURL != null) {

                backgroundImage = new ImageIcon(imageURL).getImage();

            } else {

                System.out.println("College image not found!");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            if (backgroundImage != null) {

                g.drawImage(
                    backgroundImage,
                    0, 0,
                    getWidth(), getHeight(),
                    this
                );

                g.setColor(new Color(15, 35, 65, 150));
                g.fillRect(0, 0, getWidth(), getHeight());

            } else {

                g.setColor(navy);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new LoginFrame();
        });
    }
}
