
package documentmanagementpack;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.sql.*;

public class RegisterFrame extends JFrame {

    JTextField nameField, emailField, rollField;
    JTextField contactField, parentField;
    JPasswordField passwordField, confirmPasswordField;
    JComboBox<String> genderBox, departmentBox, yearBox, sectionBox;

    Color navy = new Color(24, 48, 85);
    Color blue = new Color(48, 105, 180);
    Color background = new Color(239, 245, 253);
    Color borderColor = new Color(210, 222, 238);

    public RegisterFrame() {

        setTitle("DocuFlow - Student Registration");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setMinimumSize(new Dimension(1000, 650));

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(background);

        // Left Image Panel
        JPanel imagePanel = new JPanel(new BorderLayout());
        imagePanel.setBackground(navy);
        imagePanel.setPreferredSize(new Dimension(400, 600));

        JLabel brand = new JLabel("DocuFlow", SwingConstants.CENTER);
        brand.setFont(new Font("Arial", Font.BOLD, 32));
        brand.setForeground(Color.WHITE);
        brand.setBorder(new EmptyBorder(35, 10, 10, 10));

        JLabel tagline = new JLabel(
            "Manage  |  Request  |  Track",
            SwingConstants.CENTER
        );
        tagline.setFont(new Font("Arial", Font.PLAIN, 16));
        tagline.setForeground(Color.WHITE);

        JPanel brandPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        brandPanel.setBackground(navy);
        brandPanel.add(brand);
        brandPanel.add(tagline);

        JLabel imageLabel = new JLabel("", SwingConstants.CENTER);
        imageLabel.setBackground(navy);
        imageLabel.setOpaque(true);

        java.net.URL imageURL =
            getClass().getResource("/images/docuflow-side.png");

        if (imageURL != null) {
            ImageIcon original = new ImageIcon(imageURL);
            Image image = original.getImage().getScaledInstance(
                380, 450, Image.SCALE_SMOOTH
            );
            imageLabel.setIcon(new ImageIcon(image));
        } else {
            imageLabel.setText(
                "<html><center><font color='white' size='5'>"
                + "Student Document<br>Management System"
                + "</font></center></html>"
            );
        }

        imagePanel.add(brandPanel, BorderLayout.NORTH);
        imagePanel.add(imageLabel, BorderLayout.CENTER);

        // Right Form Panel
        JPanel rightPanel = new JPanel(new BorderLayout(10, 15));
        rightPanel.setBackground(background);
        rightPanel.setBorder(new EmptyBorder(25, 35, 25, 35));

        JLabel title = new JLabel(
            "Student Registration", SwingConstants.CENTER
        );
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(navy);

        JLabel subtitle = new JLabel(
            "Create your DocuFlow account",
            SwingConstants.CENTER
        );
        subtitle.setFont(new Font("Arial", Font.PLAIN, 15));
        subtitle.setForeground(Color.DARK_GRAY);

        JPanel heading = new JPanel(new GridLayout(2, 1, 5, 5));
        heading.setBackground(background);
        heading.add(title);
        heading.add(subtitle);

        // Form Fields
        JPanel panel = new JPanel(new GridLayout(11, 2, 12, 12));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(
            new LineBorder(borderColor, 1, true),
            new EmptyBorder(25, 30, 25, 30)
        ));

        nameField = new JTextField();
        emailField = new JTextField();
        passwordField = new JPasswordField();
        confirmPasswordField = new JPasswordField();
        rollField = new JTextField();
        genderBox = new JComboBox<>(
            new String[]{"Female", "Male", "Other"}
        );
        contactField = new JTextField();
        parentField = new JTextField();
        departmentBox = new JComboBox<>(
            new String[]{"CSE", "IT", "ECE", "EEE", "MECH", "CIVIL"}
        );
        yearBox = new JComboBox<>(
            new String[]{"1", "2", "3", "4"}
        );
        sectionBox = new JComboBox<>(
            new String[]{"A", "B", "C"}
        );

        Font labelFont = new Font("Arial", Font.BOLD, 15);
        Font fieldFont = new Font("Arial", Font.PLAIN, 15);

        JLabel[] labels = {
            new JLabel("Student Name:"),
            new JLabel("Email:"),
            new JLabel("Password:"),
            new JLabel("Confirm Password:"),
            new JLabel("Roll Number:"),
            new JLabel("Gender:"),
            new JLabel("Contact Number:"),
            new JLabel("Parent Name:"),
            new JLabel("Department:"),
            new JLabel("Year of Study:"),
            new JLabel("Section:")
        };

        JComponent[] fields = {
            nameField, emailField, passwordField,
            confirmPasswordField, rollField, genderBox,
            contactField, parentField, departmentBox,
            yearBox, sectionBox
        };

        for (int i = 0; i < labels.length; i++) {
            labels[i].setFont(labelFont);
            labels[i].setForeground(navy);

            fields[i].setFont(fieldFont);
            fields[i].setPreferredSize(new Dimension(250, 38));

            if (fields[i] instanceof JTextField) {
                fields[i].setBorder(new CompoundBorder(
                    new LineBorder(borderColor, 1, true),
                    new EmptyBorder(5, 8, 5, 8)
                ));
            }

            panel.add(labels[i]);
            panel.add(fields[i]);
        }

        JPanel formWrapper = new JPanel(new GridBagLayout());
        formWrapper.setBackground(background);
        formWrapper.add(panel);

        // Buttons
        JButton registerButton = new JButton("Register");
        JButton clearButton = new JButton("Clear");

        registerButton.setFont(new Font("Arial", Font.BOLD, 16));
        registerButton.setBackground(blue);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.setBorderPainted(false);
        registerButton.setPreferredSize(new Dimension(150, 42));

        clearButton.setFont(new Font("Arial", Font.BOLD, 16));
        clearButton.setBackground(new Color(225, 233, 244));
        clearButton.setForeground(navy);
        clearButton.setFocusPainted(false);
        clearButton.setBorderPainted(false);
        clearButton.setPreferredSize(new Dimension(150, 42));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        buttons.setBackground(background);
        buttons.add(registerButton);
        buttons.add(clearButton);

        rightPanel.add(heading, BorderLayout.NORTH);
        rightPanel.add(formWrapper, BorderLayout.CENTER);
        rightPanel.add(buttons, BorderLayout.SOUTH);

        mainPanel.add(imagePanel, BorderLayout.WEST);
        mainPanel.add(rightPanel, BorderLayout.CENTER);

        add(mainPanel);

        registerButton.addActionListener(e -> registerStudent());

        clearButton.addActionListener(e -> {
            nameField.setText("");
            emailField.setText("");
            passwordField.setText("");
            confirmPasswordField.setText("");
            rollField.setText("");
            contactField.setText("");
            parentField.setText("");
            genderBox.setSelectedIndex(0);
            departmentBox.setSelectedIndex(0);
            yearBox.setSelectedIndex(0);
            sectionBox.setSelectedIndex(0);
        });
    }

    private void registerStudent() {

        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword =
            new String(confirmPasswordField.getPassword());
        String roll = rollField.getText().trim();
        String gender = (String) genderBox.getSelectedItem();
        String contact = contactField.getText().trim();
        String parent = parentField.getText().trim();
        String department = (String) departmentBox.getSelectedItem();
        int year = Integer.parseInt((String) yearBox.getSelectedItem());
        String section = (String) sectionBox.getSelectedItem();

        if (name.isEmpty() || email.isEmpty()
                || password.isEmpty() || roll.isEmpty()
                || contact.isEmpty() || parent.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Please fill all fields."
            );
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            JOptionPane.showMessageDialog(
                this, "Enter a valid email address."
            );
            return;
        }

        String passwordPattern =
            "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)"
            + "(?=.*[^A-Za-z0-9]).{8,}$";

        if (!password.matches(passwordPattern)) {
            JOptionPane.showMessageDialog(
                this,
                "Password must contain:\n"
                + "1. Minimum 8 characters\n"
                + "2. One uppercase letter\n"
                + "3. One lowercase letter\n"
                + "4. One number\n"
                + "5. One special character"
            );
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(
                this, "Passwords do not match."
            );
            return;
        }

        if (!contact.matches("[0-9]{10}")) {
            JOptionPane.showMessageDialog(
                this, "Enter a valid 10-digit contact number."
            );
            return;
        }

        Connection con = null;

        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            String userSql =
                "INSERT INTO USERS (name, email, password, role, is_active) "
                + "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement ps =
                    con.prepareStatement(userSql, new String[]{"USER_ID"})) {

                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, password);
                ps.setString(4, "student");
                ps.setString(5, "Y");

                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {

                    if (!rs.next()) {
                        throw new SQLException("Could not generate User ID.");
                    }

                    long userId = rs.getLong(1);

                    String studentSql =
                        "INSERT INTO STUDENT "
                        + "(student_id, user_id, gender, contact_no, "
                        + "parent_name, department, year_of_study, section) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                    try (PreparedStatement ps2 =
                            con.prepareStatement(studentSql)) {

                        ps2.setString(1, roll);
                        ps2.setLong(2, userId);
                        ps2.setString(3, gender);
                        ps2.setString(4, contact);
                        ps2.setString(5, parent);
                        ps2.setString(6, department);
                        ps2.setInt(7, year);
                        ps2.setString(8, section);

                        ps2.executeUpdate();
                    }

                    con.commit();

                    JOptionPane.showMessageDialog(
                        this,
                        "Registration successful!\n"
                        + "User ID: " + userId
                        + "\nDepartment: " + department
                        + "\nSection: " + section
                    );

                    dispose();
                }
            }

        } catch (SQLException ex) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ignored) {
                }
            }

            JOptionPane.showMessageDialog(
                this, "Registration failed: " + ex.getMessage()
            );

        } finally {

            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }
}
