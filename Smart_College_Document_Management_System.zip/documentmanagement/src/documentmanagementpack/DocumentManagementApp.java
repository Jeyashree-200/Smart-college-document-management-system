package documentmanagementpack;



import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class DocumentManagementApp {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception e) {
            
        }

        SwingUtilities.invokeLater(() ->
            new LoginFrame().setVisible(true)
        );
    }
}