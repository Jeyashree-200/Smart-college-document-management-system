
package documentmanagementpack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class Notifications extends JFrame {

    private String userId;
    private JPanel notificationPanel;

    private Color navy = new Color(20, 45, 80);
    private Color blue = new Color(39, 91, 155);
    private Color background = new Color(245, 248, 252);

    public Notifications(String userId) {

        this.userId = userId;

        setTitle("DocuFlow - Notifications");
        setSize(850, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 30, 20, 30)
        );

        JLabel heading = new JLabel("My Notifications");
        heading.setFont(new Font("Arial", Font.BOLD, 26));
        heading.setForeground(navy);

        JLabel subtitle = new JLabel(
            "Stay updated about your document requests."
        );
        subtitle.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitle.setForeground(Color.GRAY);

        JPanel headingPanel = new JPanel(
            new GridLayout(2, 1, 5, 5)
        );
        headingPanel.setBackground(Color.WHITE);
        headingPanel.add(heading);
        headingPanel.add(subtitle);

        topPanel.add(headingPanel, BorderLayout.CENTER);

        notificationPanel = new JPanel();
        notificationPanel.setLayout(
            new BoxLayout(notificationPanel, BoxLayout.Y_AXIS)
        );
        notificationPanel.setBackground(background);
        notificationPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JScrollPane scrollPane = new JScrollPane(notificationPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(15);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setBorder(
            BorderFactory.createEmptyBorder(12, 20, 12, 20)
        );

        JButton refreshButton = new JButton("Refresh");
        JButton closeButton = new JButton("Close");

        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));

        refreshButton.setBackground(blue);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFocusPainted(false);

        closeButton.setBackground(Color.WHITE);
        closeButton.setForeground(navy);
        closeButton.setFocusPainted(false);

        bottomPanel.add(refreshButton);
        bottomPanel.add(closeButton);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> loadNotifications());
        closeButton.addActionListener(e -> dispose());

        loadNotifications();

        setVisible(true);
    }

    private void loadNotifications() {

        notificationPanel.removeAll();

        String sql =
            "SELECT n.notification_id, n.request_id, " +
            "n.message, n.notification_date, n.is_read " +
            "FROM NOTIFICATION n " +
            "JOIN STUDENT s ON n.student_id = s.student_id " +
            "WHERE s.user_id = ? " +
            "ORDER BY n.notification_date DESC";

        boolean found = false;

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, userId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    found = true;

                    int notificationId =
                        rs.getInt("notification_id");

                    int requestId =
                        rs.getInt("request_id");

                    boolean requestIsNull = rs.wasNull();

                    String message =
                        rs.getString("message");

                    Timestamp date =
                        rs.getTimestamp("notification_date");

                    String readStatus =
                        rs.getString("is_read");

                    boolean isRead =
                        "Y".equalsIgnoreCase(readStatus);

                    String requestValue = requestIsNull
                        ? "Not specified"
                        : String.valueOf(requestId);

                    addNotificationCard(
                        notificationId,
                        requestValue,
                        message,
                        date,
                        isRead
                    );
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Unable to load notifications.\n" + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }

        if (!found) {

            JLabel emptyLabel = new JLabel(
                "You don't have any notifications yet.",
                SwingConstants.CENTER
            );

            emptyLabel.setFont(
                new Font("Arial", Font.PLAIN, 17)
            );

            emptyLabel.setForeground(Color.GRAY);
            emptyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            notificationPanel.add(Box.createVerticalStrut(100));
            notificationPanel.add(emptyLabel);
        }

        notificationPanel.revalidate();
        notificationPanel.repaint();
    }

    private void addNotificationCard(
        int notificationId,
        String requestId,
        String message,
        Timestamp date,
        boolean isRead
    ) {

        JPanel card = new JPanel(new BorderLayout(12, 8));

        card.setBackground(Color.WHITE);
        card.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 115)
        );

        card.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    isRead ? new Color(225, 230, 238)
                           : new Color(120, 165, 210)
                ),
                BorderFactory.createEmptyBorder(15, 18, 15, 18)
            )
        );

        JPanel leftPanel = new JPanel(
            new BorderLayout(10, 5)
        );
        leftPanel.setBackground(Color.WHITE);

        JLabel icon = new JLabel(
            isRead ? "●" : "●"
        );

        icon.setFont(new Font("Arial", Font.BOLD, 18));
        icon.setForeground(
            isRead ? Color.LIGHT_GRAY : blue
        );

        JPanel messagePanel = new JPanel(
            new GridLayout(2, 1, 5, 5)
        );
        messagePanel.setBackground(Color.WHITE);

        String shortMessage = message == null
            ? "Notification"
            : message;

        JLabel messageLabel = new JLabel(shortMessage);
        messageLabel.setFont(
            new Font(
                "Arial",
                isRead ? Font.PLAIN : Font.BOLD,
                15
            )
        );
        messageLabel.setForeground(navy);

        JLabel dateLabel = new JLabel(
            date == null ? "" : date.toString()
        );

        dateLabel.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );
        dateLabel.setForeground(Color.GRAY);

        messagePanel.add(messageLabel);
        messagePanel.add(dateLabel);

        leftPanel.add(icon, BorderLayout.WEST);
        leftPanel.add(messagePanel, BorderLayout.CENTER);

        JLabel statusLabel = new JLabel(
            isRead ? "Read" : "Unread"
        );

        statusLabel.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        statusLabel.setForeground(
            isRead ? Color.GRAY : blue
        );

        card.add(leftPanel, BorderLayout.CENTER);
        card.add(statusLabel, BorderLayout.EAST);

        card.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );

        card.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                showNotificationDetails(
                    notificationId,
                    requestId,
                    message,
                    date,
                    isRead
                );
            }
        });

        notificationPanel.add(card);
        notificationPanel.add(Box.createVerticalStrut(12));
    }

    private void showNotificationDetails(
        int notificationId,
        String requestId,
        String message,
        Timestamp date,
        boolean isRead
    ) {

        JDialog dialog = new JDialog(
            this,
            "Notification Details",
            true
        );

        dialog.setSize(500, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel content = new JPanel(
            new GridLayout(0, 1, 10, 10)
        );

        content.setBackground(Color.WHITE);
        content.setBorder(
            BorderFactory.createEmptyBorder(25, 30, 20, 30)
        );

        JLabel heading = new JLabel("Notification Details");
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        heading.setForeground(navy);

        JLabel requestLabel = new JLabel(
            "Request ID: " + requestId
        );

        JLabel dateLabel = new JLabel(
            "Date: " + (date == null ? "-" : date.toString())
        );

        JLabel messageHeading = new JLabel("Message:");

        JTextArea messageArea = new JTextArea(
            message == null ? "" : message
        );

        messageArea.setFont(
            new Font("Arial", Font.PLAIN, 15)
        );

        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setEditable(false);
        messageArea.setBackground(new Color(245, 248, 252));

        JScrollPane messageScroll = new JScrollPane(messageArea);
        messageScroll.setPreferredSize(new Dimension(420, 100));

        content.add(heading);
        content.add(requestLabel);
        content.add(dateLabel);
        content.add(messageHeading);
        content.add(messageScroll);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(closeButton);

        dialog.add(content, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        closeButton.addActionListener(e -> dialog.dispose());

        if (!isRead) {
            markAsRead(notificationId);
        }

        dialog.setVisible(true);

        if (!isRead) {
            loadNotifications();
        }
    }

    private void markAsRead(int notificationId) {

        String sql =
            "UPDATE NOTIFICATION " +
            "SET is_read = 'Y' " +
            "WHERE notification_id = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, notificationId);
            ps.executeUpdate();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Unable to update notification status.\n"
                    + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
