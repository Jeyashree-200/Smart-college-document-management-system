
package documentmanagementpack;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StaffAdvisorDashboard extends JFrame {

    String advisorName;
    String userId;
    String advisorId;
    String department;
    String section;

    Color darkBlue = new Color(25, 42, 86);
    Color lightBackground = new Color(245, 247, 252);
    Color blue = new Color(55, 100, 210);
    Color green = new Color(35, 160, 110);
    Color red = new Color(220, 75, 75);

    JLabel totalLabel;
    JLabel pendingLabel;
    JLabel notificationBadge;

    JTable requestTable;
    DefaultTableModel model;

    public StaffAdvisorDashboard(String advisorName, String userId) {

        this.advisorName = advisorName;
        this.userId = userId;

        setTitle("DocuFlow - Staff Advisor Dashboard");
        setSize(1150, 700);
        setMinimumSize(new Dimension(950, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        getContentPane().setBackground(lightBackground);

        loadAdvisorDetails();

        if (department == null || section == null) {
            JOptionPane.showMessageDialog(this,
                "Advisor department or section is not assigned.");
            dispose();
            return;
        }

        JPanel sidebar = new JPanel();
        sidebar.setBackground(darkBlue);
        sidebar.setPreferredSize(new Dimension(220, 700));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("DOCUFLOW");
        logo.setFont(new Font("Arial", Font.BOLD, 25));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        logo.setPreferredSize(new Dimension(220, 90));
        logo.setMaximumSize(new Dimension(220, 90));
        logo.setHorizontalAlignment(SwingConstants.CENTER);

        sidebar.add(Box.createVerticalStrut(15));
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(25));

        JButton dashboardButton = createSideButton("Dashboard");
        JButton allRequestsButton = createSideButton("All Requests");
        JButton pendingButton = createSideButton("Pending Requests");
        JButton notificationButton = createSideButton("Notifications");
        JButton profileButton = createSideButton("My Profile");
        JButton logoutButton = createSideButton("Logout");

        notificationBadge = new JLabel("0");
        notificationBadge.setOpaque(true);
        notificationBadge.setBackground(red);
        notificationBadge.setForeground(Color.WHITE);
        notificationBadge.setFont(new Font("Arial", Font.BOLD, 12));
        notificationBadge.setHorizontalAlignment(SwingConstants.CENTER);
        notificationBadge.setPreferredSize(new Dimension(28, 23));
        notificationBadge.setVisible(false);

        JPanel notificationPanel = new JPanel(new BorderLayout(5, 0));
        notificationPanel.setBackground(darkBlue);
        notificationPanel.setPreferredSize(new Dimension(220, 48));
        notificationPanel.setMaximumSize(new Dimension(220, 48));
        notificationPanel.setMinimumSize(new Dimension(220, 48));
        notificationPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        notificationPanel.setBorder(
            BorderFactory.createEmptyBorder(0, 10, 0, 10)
        );

        notificationPanel.add(notificationButton, BorderLayout.CENTER);
        notificationPanel.add(notificationBadge, BorderLayout.EAST);

        sidebar.add(dashboardButton);
        sidebar.add(allRequestsButton);
        sidebar.add(pendingButton);
        sidebar.add(notificationPanel);
        sidebar.add(profileButton);

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(logoutButton);

        add(sidebar, BorderLayout.WEST);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(lightBackground);
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        );

        JLabel heading = new JLabel("Welcome, " + advisorName);
        heading.setFont(new Font("Arial", Font.BOLD, 25));
        heading.setForeground(darkBlue);

        JLabel subHeading = new JLabel(
            "Staff Advisor Dashboard - " + department + " / Section " + section
        );
        subHeading.setFont(new Font("Arial", Font.PLAIN, 14));
        subHeading.setForeground(Color.GRAY);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(lightBackground);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));

        headerPanel.add(heading);
        headerPanel.add(Box.createVerticalStrut(7));
        headerPanel.add(subHeading);

        JPanel cardPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        cardPanel.setBackground(lightBackground);

        totalLabel = new JLabel("0");
        pendingLabel = new JLabel("0");

        JPanel totalCard = createCard(
            "Total Requests", totalLabel, blue
        );

        JPanel pendingCard = createCard(
            "Pending Requests", pendingLabel, green
        );

        cardPanel.add(totalCard);
        cardPanel.add(pendingCard);

        JPanel topPanel = new JPanel(new BorderLayout(15, 20));
        topPanel.setBackground(lightBackground);
        topPanel.add(headerPanel, BorderLayout.NORTH);
        topPanel.add(cardPanel, BorderLayout.CENTER);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        String[] columns = {
            "Request ID",
            "Student ID",
            "Student Name",
            "Department",
            "Document Type",
            "Reason",
            "Request Date",
            "Status"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        requestTable = new JTable(model);
        requestTable.setRowHeight(32);
        requestTable.setFont(new Font("Arial", Font.PLAIN, 13));
        requestTable.setSelectionBackground(new Color(220, 230, 250));
        requestTable.setSelectionForeground(Color.BLACK);
        requestTable.setGridColor(new Color(230, 230, 230));
        requestTable.setShowVerticalLines(false);

        JTableHeader tableHeader = requestTable.getTableHeader();

        tableHeader.setDefaultRenderer(new DefaultTableCellRenderer() {

            @Override
            public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

                JLabel label = (JLabel) super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column
                );

                label.setBackground(darkBlue);
                label.setForeground(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, 14));
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setOpaque(true);

                return label;
            }
        });

        tableHeader.setPreferredSize(new Dimension(0, 45));
        tableHeader.setReorderingAllowed(false);

        // Request table display
        JScrollPane tableScrollPane = new JScrollPane(requestTable);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 12, 5)
        );
        buttonPanel.setBackground(lightBackground);

        JButton approveButton = new JButton("Approve Request");
        JButton rejectButton = new JButton("Reject Request");
        JButton refreshButton = new JButton("Refresh");

        styleButton(approveButton, green);
        styleButton(rejectButton, red);
        styleButton(refreshButton, blue);

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        dashboardButton.addActionListener(e -> {
            loadRequests(false);
            updateCounts();
        });

        allRequestsButton.addActionListener(e -> loadRequests(false));

        pendingButton.addActionListener(e -> loadRequests(true));

        notificationButton.addActionListener(e -> openNotifications());

        profileButton.addActionListener(e -> showProfile());

        logoutButton.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        approveButton.addActionListener(e -> updateRequest("Approved"));

        rejectButton.addActionListener(e -> updateRequest("Rejected"));

        refreshButton.addActionListener(e -> {
            loadRequests(false);
            updateCounts();
            refreshNotificationCount();
        });

        loadRequests(false);
        updateCounts();
        refreshNotificationCount();
    }

    private JButton createSideButton(String text) {

        JButton button = new JButton(text);

        button.setFont(new Font("Arial", Font.PLAIN, 15));
        button.setForeground(Color.WHITE);
        button.setBackground(darkBlue);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setHorizontalAlignment(SwingConstants.LEFT);

        button.setPreferredSize(new Dimension(200, 48));
        button.setMinimumSize(new Dimension(200, 48));
        button.setMaximumSize(new Dimension(200, 48));

        button.setBorder(
            BorderFactory.createEmptyBorder(10, 20, 10, 10)
        );

        button.setAlignmentX(Component.LEFT_ALIGNMENT);

        button.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(45, 65, 115));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(darkBlue);
            }
        });

        return button;
    }

    private JPanel createCard(
        String title,
        JLabel valueLabel,
        Color valueColor
    ) {

        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        card.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230)),
                BorderFactory.createEmptyBorder(18, 20, 18, 20)
            )
        );

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 15));
        titleLabel.setForeground(Color.GRAY);

        valueLabel.setFont(new Font("Arial", Font.BOLD, 30));
        valueLabel.setForeground(valueColor);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(valueLabel);

        return card;
    }

    private void styleButton(JButton button, Color color) {

        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(155, 38));
    }

    private void loadAdvisorDetails() {

        String sql =
            "SELECT advisor_id, department, section " +
            "FROM STAFF_ADVISOR WHERE user_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(userId));

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    advisorId = rs.getString("advisor_id");
                    department = rs.getString("department");
                    section = rs.getString("section");
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Staff Advisor details not found.");
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading advisor details: " + e.getMessage());
        }
    }

    private void loadRequests(boolean pendingOnly) {

        model.setRowCount(0);

        String sql =
            "SELECT dr.request_id, s.student_id, u.name, " +
            "s.department, dt.document_name, dr.reason, " +
            "dr.request_date, dr.status " +
            "FROM DOCUMENT_REQUEST dr " +
            "JOIN STUDENT s ON dr.student_id = s.student_id " +
            "JOIN USERS u ON s.user_id = u.user_id " +
            "JOIN DOCUMENT_TYPE dt ON dr.document_type_id = dt.document_type_id " +
            "WHERE s.department = ? AND s.section = ? ";

        if (pendingOnly) {
            sql += "AND dr.status = 'Pending' ";
        }

        sql += "ORDER BY dr.request_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, department);
            ps.setString(2, section);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    model.addRow(new Object[] {
                        rs.getString("request_id"),
                        rs.getString("student_id"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getString("document_name"),
                        rs.getString("reason"),
                        rs.getString("request_date"),
                        rs.getString("status")
                    });
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading requests: " + e.getMessage());
        }
    }

    private void updateRequest(String decision) {

        int selectedRow = requestTable.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Please select a request.");
            return;
        }

        String requestId =
            model.getValueAt(selectedRow, 0).toString();

        String currentStatus =
            model.getValueAt(selectedRow, 7).toString();

        if (!currentStatus.equalsIgnoreCase("Pending")) {
            JOptionPane.showMessageDialog(this,
                "Only pending requests can be processed.");
            return;
        }

        String remarks = "";

        if (decision.equals("Rejected")) {

            remarks = JOptionPane.showInputDialog(
                this, "Enter rejection reason:");

            if (remarks == null || remarks.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Rejection reason is required.");
                return;
            }
        }

        Connection con = null;

        try {

            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            boolean hodRequired = false;

            String typeSql =
                "SELECT dt.hod_approval_required " +
                "FROM DOCUMENT_REQUEST dr " +
                "JOIN DOCUMENT_TYPE dt ON dr.document_type_id = dt.document_type_id " +
                "WHERE dr.request_id = ?";

            try (PreparedStatement ps = con.prepareStatement(typeSql)) {

                ps.setInt(1, Integer.parseInt(requestId));

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        hodRequired = "Yes".equalsIgnoreCase(
                            rs.getString("hod_approval_required")
                        );
                    }
                }
            }

            String newStatus;

            if (decision.equals("Rejected")) {
                newStatus = "Rejected";
            } else if (hodRequired) {
                newStatus = "Sent to HOD";
            } else {
                newStatus = "Approved by Staff Advisor";
            }

            String updateSql =
                "UPDATE DOCUMENT_REQUEST SET status = ? " +
                "WHERE request_id = ?";

            try (PreparedStatement ps = con.prepareStatement(updateSql)) {

                ps.setString(1, newStatus);
                ps.setInt(2, Integer.parseInt(requestId));
                ps.executeUpdate();
            }

            String approvalSql =
                "INSERT INTO APPROVAL " +
                "(request_id, approver_id, approver_role, " +
                "approval_status, remarks) " +
                "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(approvalSql)) {

                ps.setInt(1, Integer.parseInt(requestId));
                ps.setInt(2, Integer.parseInt(userId));
                ps.setString(3, "STAFF_ADVISOR");
                ps.setString(4, decision);
                ps.setString(5, remarks);

                ps.executeUpdate();
            }

            if (decision.equals("Rejected")) {

                String notificationSql =
                    "INSERT INTO NOTIFICATION " +
                    "(student_id, request_id, message) " +
                    "SELECT student_id, request_id, ? " +
                    "FROM DOCUMENT_REQUEST WHERE request_id = ?";

                try (PreparedStatement ps =
                    con.prepareStatement(notificationSql)) {

                    ps.setString(1,
                        "Your document request " + requestId +
                        " has been rejected by Staff Advisor. Reason: " +
                        remarks);

                    ps.setInt(2, Integer.parseInt(requestId));
                    ps.executeUpdate();
                }
            }

            con.commit();

            JOptionPane.showMessageDialog(this,
                "Request " + decision + " successfully.");

            loadRequests(false);
            updateCounts();

        } catch (Exception e) {

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            JOptionPane.showMessageDialog(this,
                "Error updating request: " + e.getMessage());

        } finally {

            try {
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateCounts() {

        String totalSql =
            "SELECT COUNT(*) FROM DOCUMENT_REQUEST dr " +
            "JOIN STUDENT s ON dr.student_id = s.student_id " +
            "WHERE s.department = ? AND s.section = ?";

        String pendingSql =
            "SELECT COUNT(*) FROM DOCUMENT_REQUEST dr " +
            "JOIN STUDENT s ON dr.student_id = s.student_id " +
            "WHERE s.department = ? AND s.section = ? " +
            "AND dr.status = 'Pending'";

        try (Connection con = DBConnection.getConnection()) {

            try (PreparedStatement ps = con.prepareStatement(totalSql)) {

                ps.setString(1, department);
                ps.setString(2, section);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        totalLabel.setText(String.valueOf(rs.getInt(1)));
                    }
                }
            }

            try (PreparedStatement ps = con.prepareStatement(pendingSql)) {

                ps.setString(1, department);
                ps.setString(2, section);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        pendingLabel.setText(String.valueOf(rs.getInt(1)));
                    }
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading counts: " + e.getMessage());
        }
    }

    private void refreshNotificationCount() {

        String sql =
            "SELECT COUNT(*) FROM NOTIFICATION " +
            "WHERE recipient_user_id = ? AND is_read = 'N'";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(userId));

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    int count = rs.getInt(1);

                    notificationBadge.setText(
                        count > 99 ? "99+" : String.valueOf(count)
                    );

                    notificationBadge.setVisible(count > 0);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading notification count: " + e.getMessage());
        }
    }

    private void openNotifications() {

        StaffAdvisorNotifications page =
            new StaffAdvisorNotifications(userId);

        page.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosed(WindowEvent e) {
                refreshNotificationCount();
            }
        });

        page.setVisible(true);
    }


private void showProfile() {

    StaffAdvisorProfile profile = new StaffAdvisorProfile(
        advisorName,
        advisorId,
        department,
        section,
        userId
    );

    profile.setVisible(true);
}
}
