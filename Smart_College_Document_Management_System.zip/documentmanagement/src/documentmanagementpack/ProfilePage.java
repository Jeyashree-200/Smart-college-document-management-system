
package documentmanagementpack;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfilePage extends JFrame {

    private String userId;

    private JLabel avatarLabel, nameLabel, studentIdLabel;
    private JLabel emailLabel, departmentLabel, yearLabel;
    private JLabel sectionLabel, genderLabel, contactLabel, parentLabel;

    private Color darkBlue = new Color(36, 59, 83);
    private Color lightBlue = new Color(220, 232, 245);
    private Color textColor = new Color(45, 55, 72);

    public ProfilePage(String userId) {

        this.userId = userId;

        setTitle("DocuFlow - My Profile");
        setSize(850, 850);
        setMinimumSize(new Dimension(750, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);

        // Header Panel

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(darkBlue);
        headerPanel.setBorder(
            BorderFactory.createEmptyBorder(22, 35, 22, 35)
        );

        JLabel appLabel = new JLabel("DOCUFLOW");
        appLabel.setFont(new Font("Arial", Font.BOLD, 16));
        appLabel.setForeground(Color.WHITE);

        JLabel heading = new JLabel("My Profile");
        heading.setFont(new Font("Arial", Font.BOLD, 30));
        heading.setForeground(Color.WHITE);

        JLabel subHeading = new JLabel("STUDENT PERSONAL INFORMATION");
        subHeading.setFont(new Font("Arial", Font.PLAIN, 12));
        subHeading.setForeground(new Color(210, 220, 235));

        headerPanel.add(appLabel);
        headerPanel.add(Box.createVerticalStrut(10));
        headerPanel.add(heading);
        headerPanel.add(Box.createVerticalStrut(5));
        headerPanel.add(subHeading);

        // Main Content Panel

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(
            BorderFactory.createEmptyBorder(22, 35, 20, 35)
        );

        // Student Profile Section

        JPanel studentPanel = new JPanel();
        studentPanel.setLayout(new BoxLayout(studentPanel, BoxLayout.Y_AXIS));
        studentPanel.setBackground(Color.WHITE);
        studentPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        avatarLabel = new JLabel("D", SwingConstants.CENTER);
        avatarLabel.setFont(new Font("Arial", Font.BOLD, 38));
        avatarLabel.setForeground(darkBlue);
        avatarLabel.setOpaque(true);
        avatarLabel.setBackground(lightBlue);
        avatarLabel.setPreferredSize(new Dimension(95, 95));
        avatarLabel.setMinimumSize(new Dimension(95, 95));
        avatarLabel.setMaximumSize(new Dimension(95, 95));
        avatarLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        nameLabel = new JLabel("Student Name");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 23));
        nameLabel.setForeground(darkBlue);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        studentIdLabel = new JLabel("Roll Number");
        studentIdLabel.setFont(new Font("Arial", Font.PLAIN, 15));
        studentIdLabel.setForeground(Color.GRAY);
        studentIdLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel roleLabel = new JLabel("STUDENT");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        roleLabel.setForeground(new Color(45, 100, 150));
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        studentPanel.add(avatarLabel);
        studentPanel.add(Box.createVerticalStrut(12));
        studentPanel.add(nameLabel);
        studentPanel.add(Box.createVerticalStrut(5));
        studentPanel.add(studentIdLabel);
        studentPanel.add(Box.createVerticalStrut(6));
        studentPanel.add(roleLabel);

        contentPanel.add(studentPanel);
        contentPanel.add(Box.createVerticalStrut(25));

        // Personal Details Heading

        JLabel detailsHeading = new JLabel("Personal Details");
        detailsHeading.setFont(new Font("Arial", Font.BOLD, 21));
        detailsHeading.setForeground(darkBlue);
        detailsHeading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel detailsSubHeading = new JLabel(
            "Your registered student information"
        );
        detailsSubHeading.setFont(new Font("Arial", Font.PLAIN, 13));
        detailsSubHeading.setForeground(Color.GRAY);
        detailsSubHeading.setAlignmentX(Component.LEFT_ALIGNMENT);

        contentPanel.add(detailsHeading);
        contentPanel.add(Box.createVerticalStrut(5));
        contentPanel.add(detailsSubHeading);
        contentPanel.add(Box.createVerticalStrut(15));

        // Detail Labels

        emailLabel = createDetailLabel();
        departmentLabel = createDetailLabel();
        yearLabel = createDetailLabel();
        sectionLabel = createDetailLabel();
        genderLabel = createDetailLabel();
        contactLabel = createDetailLabel();
        parentLabel = createDetailLabel();

        // Detail Cards - Top to Bottom

        contentPanel.add(
            createDetailCard("ROLL NUMBER", studentIdLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("EMAIL ADDRESS", emailLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("DEPARTMENT", departmentLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("YEAR OF STUDY", yearLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("SECTION", sectionLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("GENDER", genderLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("CONTACT NUMBER", contactLabel)
        );

        contentPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(
            createDetailCard("PARENT NAME", parentLabel)
        );

        // Scroll Pane

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.setBackground(Color.WHITE);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.getVerticalScrollBar().setUnitIncrement(15);

        // Bottom Buttons

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.setBackground(darkBlue);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setOpaque(true);
        refreshButton.setBorderPainted(false);
        refreshButton.setFocusPainted(false);
        refreshButton.setPreferredSize(new Dimension(120, 40));

        refreshButton.addActionListener(e -> loadProfile());

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setBackground(new Color(235, 238, 242));
        closeButton.setForeground(textColor);
        closeButton.setFocusPainted(false);
        closeButton.setPreferredSize(new Dimension(120, 40));

        closeButton.addActionListener(e -> dispose());

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 15, 12)
        );

        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(
            BorderFactory.createEmptyBorder(0, 20, 5, 25)
        );

        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);

        // Add Panels

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        loadProfile();
    }

    // Create Detail Label

    private JLabel createDetailLabel() {

        JLabel label = new JLabel("Not provided");
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(textColor);

        return label;
    }

    // Create Full Width Detail Card


private JPanel createDetailCard(String heading, JLabel valueLabel) {

    JPanel card = new JPanel();
    card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
    card.setBackground(new Color(245, 248, 252));

    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(225, 232, 240)
            ),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)
        )
    );

    card.setAlignmentX(Component.LEFT_ALIGNMENT);
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));
    card.setPreferredSize(new Dimension(700, 75));

    JLabel titleLabel = new JLabel(heading);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 13));
    titleLabel.setForeground(Color.GRAY);
    titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

    valueLabel.setFont(new Font("Arial", Font.BOLD, 18));
    valueLabel.setForeground(textColor);
    valueLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

    card.add(titleLabel);
    card.add(Box.createVerticalStrut(8));
    card.add(valueLabel);

    return card;
}

    // Load Student Profile from Database

    private void loadProfile() {

        String sql =
            "SELECT s.student_id, u.name, u.email, " +
            "s.department, s.year_of_study, s.section, s.gender, " +
            "s.contact_no, s.parent_name " +
            "FROM STUDENT s " +
            "JOIN USERS u ON s.user_id = u.user_id " +
            "WHERE u.user_id = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, userId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    String name = value(rs.getString("name"));

                    nameLabel.setText(name);

                    String rollNumber = value(
                        rs.getString("student_id")
                    );

                    studentIdLabel.setText(rollNumber);

                    avatarLabel.setText(
                        name.equals("Not provided")
                        ? "?"
                        : name.substring(0, 1).toUpperCase()
                    );

                    emailLabel.setText(
                        value(rs.getString("email"))
                    );

                    departmentLabel.setText(
                        value(rs.getString("department"))
                    );

                    yearLabel.setText(
                        value(rs.getString("year_of_study"))
                    );

                    sectionLabel.setText(
                        value(rs.getString("section"))
                    );

                    genderLabel.setText(
                        value(rs.getString("gender"))
                    );

                    contactLabel.setText(
                        value(rs.getString("contact_no"))
                    );

                    parentLabel.setText(
                        value(rs.getString("parent_name"))
                    );

                } else {

                    JOptionPane.showMessageDialog(
                        this,
                        "Student details not found."
                    );
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "Unable to load profile: " + ex.getMessage()
            );
        }
    }

    // Handle Empty Database Values

    private String value(String text) {

        return text == null || text.trim().isEmpty()
                ? "Not provided" : text;
    }
}
